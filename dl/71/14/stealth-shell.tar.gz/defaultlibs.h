#include "freestanding.h"

extern struct fs_mutex malloc_lock;
