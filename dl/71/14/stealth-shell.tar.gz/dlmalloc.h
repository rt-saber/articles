#ifndef DLMALLOC_H
#define DLMALLOC_H

int dlmalloc_trim(size_t);

#endif
