#ifdef __x86_64__
#include "syscall_defs_x86_64.h"
#endif

#ifdef __aarch64__
#include "syscall_defs_aarch64.h"
#endif
