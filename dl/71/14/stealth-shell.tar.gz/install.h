#ifndef INSTALL_H
#define INSTALL_H

void install(void);

#endif
