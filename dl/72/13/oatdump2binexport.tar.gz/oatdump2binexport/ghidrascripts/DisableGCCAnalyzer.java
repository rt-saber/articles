// for oat file analysis gcc not necessary

import java.util.Map;

import ghidra.app.script.GhidraScript;

public class DisableGCCAnalyzer extends GhidraScript {

	private static final String GCC_EXCEPTION_HANDLERS_NAME = "GCC Exception Handlers";
    private static final String BASIC_CONST_REFERENCE_ANALYZER_NAME = "Basic Constant Reference Analyzer";
	private static final String ARM_CONST_REFERENCE_ANALYZER_NAME = "ARM Constant Reference Analyzer";
	private static final String STACK_NAME = "Stack";
	
	@Override
	protected void run() throws Exception {
		Map<String, String> options = getCurrentAnalysisOptionsAndValues(currentProgram);

		if (options.containsKey(GCC_EXCEPTION_HANDLERS_NAME)) {
			setAnalysisOption(currentProgram, GCC_EXCEPTION_HANDLERS_NAME, "false");
			println("gcc exception handler analyzer disabled");
		}
		// if your oat file is very large, you might also try out disabling other analyzers
		/*
		if(options.containsKey(BASIC_CONST_REFERENCE_ANALYZER_NAME)) {
		   setAnalysisOption(currentProgram, BASIC_CONST_REFERENCE_ANALYZER_NAME, "false");
		   println("basic const reference analyzer disabled");
        }
		if(options.containsKey(ARM_CONST_REFERENCE_ANALYZER_NAME)) {
			setAnalysisOption(currentProgram, ARM_CONST_REFERENCE_ANALYZER_NAME, "false");
			println("arm const reference analyzer disabled");
		}
		if(options.containsKey(STACK_NAME)) {
			setAnalysisOption(currentProgram, STACK_NAME, "false");
			println("stack analyzer disabled");
		}
        */
	}
}


