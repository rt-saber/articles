//Export functions as BinExport file named by first argument

import ghidra.app.script.GhidraScript;
import java.io.File;
import java.io.IOException;
import ghidra.program.model.address.AddressSet;
import ghidra.app.util.exporter.Exporter;
import ghidra.app.util.exporter.ExporterException;
import com.google.security.binexport.BinExportExporter;

public class OatBinExport extends GhidraScript {

    @Override
    protected void run() throws Exception {
        println("BinExporter: started");
        String[] args = getScriptArgs();
	
    	String filename = ""+currentProgram.getName()+".BinExport";
    	if(args.length > 0) {
        	filename = args[0];
    	}

        File f = new File(filename);
        println("BinExporter: saving to:"+f.getAbsolutePath());

        Exporter exporter = new BinExportExporter();
        AddressSet as = new AddressSet();
        currentProgram.getFunctionManager().getFunctions(true).forEach((fun) -> as.add(fun.getBody()));

        println("BinExporter: got "+as.getNumAddresses()+" addresses");

        boolean success = false;
        try {
            success = exporter.export(f, currentProgram, as, monitor);
        } catch(ExporterException e) {
            println("BinExporter: got exporterexception");
            println(e.toString());
        } catch(IOException e) {
            println("BinExporter: got IOException");
            println(e.toString());
        }

        if(success){
            println("BinExporter: export successful!");
        } else {
            println("BinExporter: export failed!");
        }
    }
}

