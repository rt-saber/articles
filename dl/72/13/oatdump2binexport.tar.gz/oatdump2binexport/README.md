# Readme

## Installation

We assume you have `curl`, `protoc`, and `uv` installed.

```console
curl https://raw.githubusercontent.com/google/binexport/refs/tags/v12/binexport2.proto -o od2be/binexport2.proto
protoc --proto_path=od2be --python_out=od2be od2be/binexport2.proto 
uv sync
```

## Usage

`uv run oatdump2binexport app.odex app.oatdump app.BinExport`

## External Dependency Versions

- libprotoc: 3.21.12


## ghidra binexport

The shell script "ghidra_export_binexport.sh" provides an easy interface to headleslly convert binary (oat) files to binexport files. It also uses a pre-analysis script to disable Analysis passes as they don't make sense for oats in order to speed up ghidras decompilation.
