import hashlib
import os
import re
import sys
import time
from collections import defaultdict
from pathlib import Path

import click
import readelf
import tqdm
from loguru import logger

from od2be.binexport2_pb2 import BinExport2


class OatDumpParsingError(Exception):
    pass


class OatData:
    def __init__(self, odex_path, oatdump_path, extra_offset=0):
        self.odex_path = odex_path
        self.oatdump_path = oatdump_path
        self.oatdata_offset = self.get_oatdata_offset()+extra_offset
        self.extra_offset = extra_offset
        self.headers = {}
        self.methods = {}

        self.sections = []

        self.__line_array = []
        self.__raw_methods = []

        self.parse()

        self.arch_name = self.headers["instruction_set"]
        self.sha256 = sha256_from_file(self.odex_path)

    def get_oatdata_offset(self):
        # alternatively: readelf -s $OAT_FILE | grep -w oatdata | awk '{{print "0x"$2}}
        offset = readelf.readelf(self.odex_path).find_section(".dynsym").get_symbol("oatdata").section.addr
        return offset

    def parse(self):
        with open(self.oatdump_path, "rb") as f:
            self.__line_array = f.readlines()

        self._parse_oatdump_header()

        if False: # debug
            logger.trace("read oatdump header:")
            for k,v in self.headers.items():
                if k != "kv":
                    logger.trace(f" - {k}: {v}")
            else:
                logger.trace(" - kv:")
                for i,j in v.items():
                    logger.trace(f"   - {i}: {j}")

        self._parse_sections()

        self._parse_oatdump_methods()

    def _parse_sections(self):
        odex = readelf.readelf(self.odex_path)
        for section in odex.sections:
            flags = section.flags
            self.sections.append((
                    section.addr,
                    section.size,
                    bool(readelf.const.SHF.SHF_ALLOC in flags),
                    bool(readelf.const.SHF.SHF_WRITE in flags),
                    bool(readelf.const.SHF.SHF_EXECINSTR in flags),
            ))

    def _parse_oatdump_header(self):
        logger.debug("parsing oatdump headers")
        assert(self._r(0) == "MAGIC:")
        assert(self._r(1).strip() == "oat")
        oat_version = int(self._r(2))
        self.headers["version"] = oat_version
        if oat_version != 257:
            logger.warning(f"expected oat version 247 but got {oat_version}")

        # empty, LOCATION, <location>, Empty, CHECKSUM:, <checksum>
        assert(self._r(10) == "INSTRUCTION SET:")
        self.headers["instruction_set"] = self._r(11).lower()
        # empty, INST SET FEATURES, <features>, empty
        assert(self._r(16) == "DEX FILE COUNT:")
        self.headers["dex_filecount"] = int(self._r(17))
        # empty
        assert(self._r(19) == "EXECUTABLE OFFSET:")
        self.headers["executable_offset"] = int(self._r(20), 16)

        self.headers["kv"] = self._find_and_get_kvstore()

    def _r(self, line_no):
        return self.__line_array[line_no].decode("utf-8", "backslashreplace").strip()

    def _raw(self, line_no):
        return self.__line_array[line_no].decode("utf-8", "backslashreplace")

    def _find_and_get_kvstore(self):
        line_no = 21
        line = self._r(line_no)
        while line != "KEY VALUE STORE:":
            if line_no > 1000: # something went wrong
                raise OatDumpParsingError("KEY VALUE STORE not found after 1000 lines.") # that's not reasonable
            line_no+=1
            line = self._r(line_no)
        line_no+=1
        line = self._r(line_no)
        kvstore = {}
        while line != "":
            if line_no > 1000:
                raise OatDumpParsingError("KEY VALUE STORE still parsing after 1000 lines.") # that's not reasonable
            k, v = line.split(" = ", 1)
            kvstore[k] = v
            line_no+=1
            line = self._r(line_no)
        return kvstore

    def _parse_oatdump_methods(self):
        logger.debug("parsing oatdump methods")

        re_dxfile = re.compile(b"^OatDexFile:")
        re_cls = re.compile(b"^[0-9]+: ")
        re_mtd = re.compile(b"^  [0-9]+: ")

        # we find the indices of lines ahead of time so navigation is easier
        dexfile_lines = [(i, "dex") for i,d in enumerate(self.__line_array) if bool(re_dxfile.match(d))]
        class_lines = [(i, "cls") for i,d in enumerate(self.__line_array) if bool(re_cls.match(d))]
        method_lines = [(i, "mtd") for i,d in enumerate(self.__line_array) if bool(re_mtd.match(d))]

        # consistency check
        assert(len(dexfile_lines) == self.headers["dex_filecount"])

        # make one sorted array for all so we can iterate
        dxclsmtd_lines = sorted(dexfile_lines + class_lines + method_lines)

        __current_dexfile = None
        __current_class = None
        __current_class_idx = None

        # the list of lines has to start with a dex file and then a class
        assert(dxclsmtd_lines[0][1] == "dex")
        assert(dxclsmtd_lines[1][1] == "cls")
        for line_no, line_type in tqdm.tqdm(dxclsmtd_lines):
            if line_type == "dex":
                # update current dex file
                __current_dexfile = self._parse_dexline(line_no)
            elif line_type == "cls":
                # update current class
                __current_class, __current_class_idx = self._parse_classline(line_no)
            elif line_type == "mtd":
                # parse current method
                self._parse_method(line_no)

    def _parse_dexline(self, line_no):
        line = self._r(line_no+1)
        assert(line.startswith("location: "))
        file_dex_string = os.path.basename(line[10:])
        #dex ids are appended after the filename with an '!' except for the first one.
        if '!' in file_dex_string:
            return file_dex_string.split('!')[-1]
        else:
            return ""

    def _parse_classline(self, line_no):
        line = self._r(line_no)
        class_name = line.split(" ")[1]
        if "type_idx=" in line:
            class_idx = int(line.split("type_idx=")[1].split(")")[0])
        else:
            class_idx = -1 # NOTE can happen if classline is like: "12345: Landroidx/transition/ViewUtilsApi23;"
        return class_name, class_idx

    def _parse_method(self, line_no):
        method_sig, method_dex_idx, code_offset, code_size, has_code, code_line_at = self._parse_method_line(line_no)
        if(has_code):
            method_code = self._parse_method_code(code_line_at)
        else:
            method_code = []

        dex_targets = self._parse_method_dex_call_targets(line_no)

        # here we save all that is necessary
        self.__raw_methods.append((method_sig, method_dex_idx, code_offset, code_size, has_code, code_line_at, method_code, dex_targets))

    def _parse_method_line(self, line_no):
        line = self._r(line_no)
        # we can assume (dex_method_idx is only stuff after method), see https://android.googlesource.com/platform/art/+/master/oatdump/oatdump.cc#1110
        dx_mtd_split = line.split(" (dex_method_idx=")

        method_sig = " ".join(dx_mtd_split[0].split(' ')[1:])
        method_dex_idx = int(dx_mtd_split[1].split(")")[0])

        # NOTE: the offset is from the start of the oatdata section
        i = line_no
        while not line.startswith("CODE: "):
            i+=1
            line = self._r(i)
        code_offset = int(line.split("code_offset=")[1].split(" ")[0], base=16)
        code_size = int(line.split("size=")[1].split(")")[0])

        has_code = self._r(i+1) != "NO CODE!"
        code_line_at = i

        return method_sig, method_dex_idx, code_offset, code_size, has_code, code_line_at

    def _parse_method_code(self, line_no):
        # this deals with the disassembly
        code = []
        #logger.trace(self._r(line_no))
        i = line_no+1
        line = self._raw(i)
        while line.startswith("      "): # 6 spaces
            if not line.startswith("        "): # 8 spaces
                addr, binary_hex, mnemonic, arguments = self._parse_code_line(line)
                #logger.trace((addr, binary_hex, mnemonic, arguments))
                code.append((addr, binary_hex, mnemonic, arguments))
            i+=1
            line = self._raw(i)
        return code

    def _parse_method_dex_call_targets(self, line_no):
        # this extracts the target dalvik methods for the callgraph
        targets = []
        i = line_no+1
        line = self._raw(i)
        while "VERIFIER TYPE ANALYSIS:" not in line:
            if "invoke" in line:
                #logger.trace(line.strip())
                match = re.search(r'\b([\w\$<>.]+)\s*\(', line)
                if match:
                    #logger.trace(match.group(1))
                    targets.append(match.group(1))
            i+=1
            line = self._raw(i)
        return targets

    def _parse_code_line(self, line):
        parts = line.strip().replace('\t', ' ').split(' ')
        addr = int(parts[0][:-1], 16)
        binary_hex = parts[1]
        mnemonic = parts[2]
        arguments = ' '.join(parts[3:])
        return addr, binary_hex, mnemonic, arguments

    def get_raw_methods(self):
        return self.__raw_methods


class IndexedSet:
    """
    BinExport refers to indices of certain things, so we use this class to keep track of them.
    would index() be faster and smaller? maybe, this is easier to read
    """
    def __init__(self):
        self._i = 0
        self._dict = {}

    def add(self, key):
        if key in self._dict:
            idx = self._dict[key]
        else:
            idx = self._i
            self._dict[key] = idx
            self._i+=1
        return idx

    def indexOf(self, key):
        return self._dict.get(key, None)

    def items(self):
        return self._dict.items()

    def nextIndex(self):
        return self._i


class OatBinExportWriter:
    def __init__(self, oat_data):
        self.od = oat_data
        self._addr_pattern = r"\(addr 0x([0-9a-f]+)\)"

        self.instruction_details = {}
        self.bbaddr_to_bbdata = {}
        self.method_address_to_info = {}
        self.method_name_to_address = {}

        self.addresses_that_begin_bb = set()


        self.iset_mnemonic = IndexedSet() # technically should be sorted, but w/e
        self.iset_expression = IndexedSet()
        self.iset_instruction = IndexedSet()
        self.iset_basicblock = IndexedSet() # indexed by first instruction
        self.iset_function = IndexedSet()

        self.be = BinExport2()

    def write(self, binexport_file):
        self.prepare_binexport()
        logger.debug("writing binexport to file")
        with open(binexport_file, "wb") as f:
            f.write(self.be.SerializeToString())

    def map_archname(self, archname):
        # ghidra names things differently than android, sync with it
        if archname.strip() == "arm64":
            return "AARCH64-64"
        else:
            logger.warning(f"got architecture '{archname.strip()}', but unsure how to map to Ghidras arch names.")

    def prepare_binexport(self):
        # some notes on design:
        # we use the offsets from oatdump until we add to binexport, at which point we'll add the oatdata offset.
        # we also keep the operand expression as provided by oatdum, they are decimal. ghidra exports them as hex
        logger.debug("starting binexport")
        self.be.meta_information.executable_name = Path(self.od.odex_path).name # keep consistent with ghidra output
        self.be.meta_information.executable_id = self.od.sha256
        self.be.meta_information.architecture_name = self.map_archname(self.od.arch_name)
        self.be.meta_information.timestamp = int(time.time())

        self._prepare_methods()
        self.resolve_and_add_methods()

    def resolve_and_add_methods(self):
        # resolving works that we go over everything we have and build indexed sets as we go. then we actually add these indexed sets to the protobuf

        logger.debug("resolving data to indices")

        mnemonic_count = defaultdict(int)

        for m_address, m_data in tqdm.tqdm(self.method_address_to_info.items()):
                m_mangled_name, parsed_bbs, _ = m_data
                self.iset_function.add(m_address)
                first_bb_addr = None
                for bb_address, bb_data in parsed_bbs.items():
                    if not first_bb_addr:
                        first_bb_addr = bb_address
                    bb_instructions, targets = bb_data

                    self.bbaddr_to_bbdata[bb_address] = (bb_instructions, targets)

                    self.iset_basicblock.add(bb_address)

                    for inst_addr in bb_instructions:
                        self.iset_instruction.add(inst_addr)

                        mnemonic, arguments, _, _ = self.instruction_details[inst_addr]

                        mnemonic_count[mnemonic]+=1
                        self._expr_op_idcs_from_arguments(arguments)
                assert(first_bb_addr == m_address)

        for _mnemonic, _ in sorted(mnemonic_count.items(), key=lambda item: item[1], reverse=True):
            self.iset_mnemonic.add(_mnemonic)

        self._be_add_mnemonic()
        self._be_add_expression_operands()

        self._be_add_instructions()
        self._be_add_basic_blocks() # needs to be before flow_graph

        """
        self._be_add_comments()        Don't appear in ghidra
        self._be_add_strings()         Unused?
        self._be_add_data_references() Don't appeas in ghidra
        """

        self._be_add_flow_graph()

        self._be_add_sections()


        self._be_add_call_graphs()

    def _be_add_sections(self):
        for addr, size, r, w, x in self.od.sections:
            self.be.section.add(
                    address=addr+self.od.extra_offset,   # no need for oatdata fix
                    size=size,
                    flag_r=r,
                    flag_w=w,
                    flag_x=x
                )

    def _expr_op_idcs_from_arguments(self, arguments):
        idcs = []
        if len(arguments) > 0:
            for e in self._arguments_to_expressions(arguments):
                idcs.append(self.iset_expression.add(e))
        return idcs

    def _be_add_mnemonic(self):
        logger.debug("wrapping up mnemonics")
        # technically they should be sorted by occurence with references to 0 index being skipped, but we'll just leave it
        for m, _ in self.iset_mnemonic.items():
            self.be.mnemonic.add(name=m)

    def _be_add_expression_operands(self):
        logger.debug("wrapping up expressions and operands")
        # expressions should be saved as tree, but ghidra doesn't, so we skip this too
        for e, i in self.iset_expression.items():
            self.be.expression.add(
                    type="SYMBOL",
                    symbol=e,
            )
            self.be.operand.add(expression_index=[i])

    def _be_add_instructions(self):
        logger.debug("wrapping up instructions")
        for addr, _i in self.iset_instruction.items():
            #logger.trace((addr, i))
            mnemonic, arguments, raw_bytes, raw_call_target = self.instruction_details[addr]
            #logger.trace((mnem_idx, expr_op_idcs, raw_bytes))

            fixed_addr = self.fixoffs(addr) # TODO only for beginnning of BB?
            mnem_idx = self.iset_mnemonic.indexOf(mnemonic)
            expr_op_idcs = self._expr_op_idcs_from_arguments(arguments)

            #logger.trace(raw_call_target)
            if raw_call_target:
                self.be.instruction.add(
                        address=fixed_addr,  # TODO only for beginning of BB?
                        mnemonic_index=mnem_idx,
                        operand_index=expr_op_idcs,
                        call_target=[self.fixoffs(raw_call_target)],
                        raw_bytes=raw_bytes
                )
            else:
                self.be.instruction.add(address=fixed_addr, mnemonic_index=mnem_idx, operand_index=expr_op_idcs, raw_bytes=raw_bytes
                )

    def _be_add_basic_blocks(self):
        logger.debug("wrapping up adding bbs")
        for bb_addr, _i in self.iset_basicblock.items():
            bb_instructions, targets = self.bbaddr_to_bbdata[bb_addr]

            begin_idx = self.iset_instruction.indexOf(bb_instructions[0])
            end_idx = self.iset_instruction.indexOf(bb_instructions[-1])
            if begin_idx == end_idx:
                ir = BinExport2.BasicBlock.IndexRange(begin_index=begin_idx)
            else:
                ir = BinExport2.BasicBlock.IndexRange(begin_index=begin_idx, end_index=end_idx+1)
            # another hack = we ignore disconnected ranges
            self.be.basic_block.add(instruction_index=[ir])


    def _be_add_flow_graph(self):
        for _m_address, m_data in self.method_address_to_info.items():
            m_mangled_name, parsed_bbs, _ = m_data

            bb_idcs = []
            entry_idx = None
            edges = []

            for bb_address, bb_data in parsed_bbs.items():
                _, targets = bb_data
                bb_idx = self.iset_basicblock.indexOf(bb_address)
                if not entry_idx:
                    entry_idx = bb_idx
                bb_idcs.append(bb_idx)


                if len(targets) == 2: # conditional branch in function
                    t1 = self._bb_target_address_to_target_bb_index(targets[0], bb_idx)
                    t2 = self._bb_target_address_to_target_bb_index(targets[1], bb_idx)
                    # just to be sure we test the order
                    if targets[0] == -1:
                        t1, t2 = t2, t1

                    edges.append(BinExport2.FlowGraph.Edge(type="CONDITION_TRUE",  source_basic_block_index=bb_idx, target_basic_block_index=t1))
                    edges.append(BinExport2.FlowGraph.Edge(type="CONDITION_FALSE",  source_basic_block_index=bb_idx, target_basic_block_index=t2))

                elif len(targets) == 1: #unconditional branch in function
                    t = self._bb_target_address_to_target_bb_index(targets[0], bb_idx)
                    edges.append(BinExport2.FlowGraph.Edge(source_basic_block_index=bb_idx, target_basic_block_index=t))
                else:
                    pass # ret / out of function branch

            self.be.flow_graph.add(entry_basic_block_index=entry_idx, basic_block_index=bb_idcs, edge=edges)

    def _bb_target_address_to_target_bb_index(self, target, i):
        # if target is -1 it means fall through, so we take the next bb index
        if target == -1:
            return i+1
        # else target is an address we need to resolve:
        else:
            return self.iset_basicblock.indexOf(target)

    def _be_add_call_graphs(self):
        logger.debug("wrapping up callgraph")
        for addr, i in self.iset_function.items():
            m_mangled_name, _, call_targets = self.method_address_to_info[addr]
            #logger.trace(m_mangled_name)
            #logger.trace(call_targets)
            self.be.call_graph.vertex.add(
                    address=self.fixoffs(addr),
                    mangled_name=m_mangled_name)
            for target_name in call_targets:
                #logger.trace(target_name)
                if target_name in self.method_name_to_address:
                    target_address = self.method_name_to_address[target_name]
                    target_idx = self.iset_function.indexOf(target_address)
                    if target_idx:
                        self.be.call_graph.edge.add(
                                source_vertex_index=i, target_vertex_index=target_idx)

    def fixoffs(self, address):
        return int(address+self.od.oatdata_offset)

    def _prepare_methods(self):
        logger.debug("preparing methods")
        for m in tqdm.tqdm(self.od.get_raw_methods()):
            method_sig, method_dex_idx, code_offset, code_size, has_code, code_line_at, method_code, dex_targets = m

            if not has_code:
                # if methods has no binary code, skip
                # can be JNI, inlined, ..
                continue

            m_address = code_offset #+self.od.oatdata_offset
            m_mangled_name = self._method_sig_to_mangled_name(method_sig)
            parsed_bbs = self.bbs_from_method(method_code, [code_offset, code_offset+code_size])

            if False: # debugging
                logger.trace(f"------------------- method {m_mangled_name}")
                for instr, bbinfo in parsed_bbs.items():
                    logger.trace(f"=== bb at {hex(instr)}")
                    _current_bb, targets = bbinfo
                    for i in _current_bb:
                        logger.trace(f"---- {hex(i)}: {self.instruction_details[i]}")
                    logger.trace(f"   targets: {[hex(t) for t in targets]}")

            self.method_address_to_info[m_address] = (
                m_mangled_name,
                parsed_bbs,
                dex_targets
            )

            self.method_name_to_address[m_mangled_name] = m_address

    def bbs_from_method(self, method_code, method_range):
        # one silly thing: code blocks can contain dummy instructions like `ldr xzr` for data after the last ret
        # one good thing: the binary is not doing funny things like reusing basic blocks in other functions, so we can assume that we don't need to create a new basic block in the middle of an existing one
        # still, we'll first parse all instructions and targets, and then split the bbs up
        """returns dict[first_instruction_addr] = ([list_instruction_addrs], [list_target_addrs and -1 for next])"""

        _instructions = [] # list of _current_bbs
        _instructions_that_end_bb = {} # map to (un) conditional jumps
        _target_addresses = set()
        _ends_on_data = False

        for inst_addr, binary_hex, mnemonic, raw_arguments in method_code:
            if mnemonic == "unallocated" or mnemonic == "udf":
                # technically there can be a dummy instruction before that we'd need to discard as well, but we'll leave it for the POC
                _ends_on_data = True
                continue

            parsed_arguments = self._parse_arguments(raw_arguments)

            _instructions.append(inst_addr)

            # deal with jumps and bb targets. we'll use a hack^W heuristic to check if the target is in our function, else we ignore it

            raw_call_target = None
            if self._does_mnem_end_bb(mnemonic):
                # another hack^W heuristic for the jump targets
                # if we can parse an addr from the arguments (and we're looking at a jump-inducing instruction), we just use that, if it's in our own function

                if mnemonic in ['ret']: # always ends a bb, eret doesn't occur afaik
                    _instructions_that_end_bb[inst_addr] = []
                else:
                    target = self._get_target_addr_from_jump(raw_arguments)
                    raw_call_target = target
                    #logger.trace(f"--- {mnemonic} {raw_arguments} ---- {target}")
                    # this "in current function check" will also ditch `bl` to thunk functions. they are not in the oatdump, so oh well. ghidra finds them tho and includes the bb as jump target.
                    if target and method_range[0] <= target < method_range[1]:
                        # it's in our function, so add it and end the current bb
                        _target_addresses.add(target)
                        if mnemonic.startswith("b.") or mnemonic in ["cbz", "cbnz", "tbz", "tbnz"]:
                            # conditional mnemonic, save true and fals branch
                            _instructions_that_end_bb[inst_addr] = [target, -1]
                        else:
                            # unconditional, always to there
                            _instructions_that_end_bb[inst_addr] = [target]
                        # FIXME: we're not finding switch statements like this that ghidra does:
                        """
                        0x004a38e0: 10009171	adr x17, #+0x122c (addr 0x4a4b0c)
                        0x004a38e4: b8615a30	ldr w16, [x17, w1, uxtw #2]
                        0x004a38e8: 8b30c231	add x17, x17, w16, sxtw
                        0x004a38ec: d61f0220	br x17
                        """
                    # FUTURE: at some point we could get so much more from oatdumps.


            # we'll add our instruction to the rest
            self._add_to_instr_details(
                inst_addr,
                mnemonic,
                parsed_arguments,
                binary_hex,
                raw_call_target
            ) # FUTURE: at some point doublecheck we add new instructions

        # now parse everything
        # dict that maps the first instruction address to a tuple:
        # ([inst in bb], [targets]) the special target -1 means fallthrough to the next
        basic_blocks = {}
        # true target is a hack: because the default is fallthrough
        _current_bb = []
        _current_first_instr = None
        for inst_addr in _instructions:
            # if the current instructio is a target, close the bb and start a new
            if inst_addr in _target_addresses:
                # if the previous instruction was a jump, we have an empty _current_bb
                # so we don't need to do anything
                if len(_current_bb) > 0:
                    # if we close a bb because the next is a target, we add an edge to next
                    basic_blocks[_current_first_instr] = (_current_bb, [-1])
                    _current_bb = []

            # add the current instruction to the bb, it's a fresh one if it's a target, or if the previous one was a jump
            _current_bb.append(inst_addr)
            if len(_current_bb) == 1:
                _current_first_instr = inst_addr

            # if the current instruction is a jump, close the bb and start a new one
            if inst_addr in _instructions_that_end_bb:
                target = _instructions_that_end_bb[inst_addr]
                basic_blocks[_current_first_instr] = (_current_bb, target) # resolved targets
                _current_bb = []

        if not _ends_on_data and len(_current_bb) > 0:
            # because of the silly instructions after the last ret drop the bb if we found extra data
            basic_blocks[_current_first_instr] = (_current_bb, [])

        return basic_blocks

    def _parse_arguments(self, args):
        r = args.split('(')[0].strip()
        r = r.split(';')[0].strip()
        return r

    def _add_to_instr_details(self, inst_addr, mnemonic, arguments, binary_hex, raw_call_target):
        raw_bytes = self._hex_to_intlist(binary_hex)
        if inst_addr in self.instruction_details:
            # dubblecheck that we stay consistent
            assert(mnemonic == self.instruction_details[inst_addr][0])
            assert(arguments == self.instruction_details[inst_addr][1])
            assert(raw_bytes == self.instruction_details[inst_addr][2])
            assert(raw_call_target == self.instruction_details[inst_addr][3])
            return False
        else:
            self.instruction_details[inst_addr] = (
                mnemonic,
                arguments,
                raw_bytes,
                raw_call_target
            )
            return True

    def _get_target_addr_from_jump(self, arguments):
        match = re.search(self._addr_pattern, arguments)
        return int(match.group(1), 16) if match else None

    def _hex_to_intlist(self, hex_str):
        byte_chunks = [hex_str[i:i+2] for i in range(0, len(hex_str), 2)]
        byte_chunks.reverse()
        return bytes.fromhex(''.join(byte_chunks))

    def _method_sig_to_mangled_name(self, method_sig):
        return method_sig.split('(')[0].split(' ')[1]

    def _arguments_to_expressions(self, arguments):
        # arguments can have more info than just disassembly, we use that
        expressions = []
        current_expr = ""
        _just_finished = False
        _in_brackets = False
        _check_writeback = False
        for c in arguments:
            if _check_writeback:
                if c == '!':
                    current_expr+=c
                    expressions.append(current_expr)
                    _just_finished = True
                    current_expr = ""
                elif c == ' ':
                    expressions.append(current_expr)
                    _just_finished = True
                    current_expr = ""
                elif c == ',':
                    # technically same as below but w/e
                    expressions.append(current_expr)
                    _just_finished = True
                    current_expr = ""
                else:
                    assert(False)
                _check_writeback = False
                continue
            if _just_finished:
                assert(c == ' ')
                _just_finished = False
                continue
            if c == ',' and not _in_brackets:
                expressions.append(current_expr)
                _just_finished = True
                current_expr = ""
                continue
            if c == '[':
                _in_brackets = True
            if c == ']':
                _check_writeback = True
            current_expr+=c
        expressions.append(current_expr)
        expressions = [e for e in expressions if e != ""] # FUTURE figure out why this happens
        return expressions

    def _does_mnem_end_bb(self, mnemonic):
        m = mnemonic.lower()

        # not a full list but android doesn't seem to use others
        # see also the AARCH64base.sinc in Ghidra for "call", "goto", and "return"
        break_mnems = {
            "b", "br", "bl", "blr", "ret",
            "cbz", "cbnz",
            "tbz", "tbnz",
            "brk"}

        return (m in break_mnems or m.startswith("b."))


def sha256_from_file(filename):
    sha256_hash = hashlib.sha256()
    with open(filename,"rb") as f:
        # Read and update hash string value in blocks of 4K
        for byte_block in iter(lambda: f.read(4096),b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()


@click.command()
@click.argument("odex_in")
@click.argument("oatdump_in")
@click.argument("binexport_out")
@click.option("--extra-offset", default="0x100000", help="Add offset to all methods like Ghidra does.", show_default=True)
@click.option("--verbosity", default="INFO", type=click.Choice(['TRACE', 'DEBUG', 'INFO', 'WARNING'], case_sensitive=False), show_default=True)
@logger.catch()
def main(odex_in, oatdump_in, binexport_out, extra_offset, verbosity):
    logger.remove()
    logger.add(sys.stdout, level=verbosity)

    oat_data = OatData(odex_in, oatdump_in, extra_offset=int(extra_offset, 16))

    oat_binexport_writer = OatBinExportWriter(oat_data)

    oat_binexport_writer.write(binexport_out)

    print("done! \\o/")


if __name__ == "__main__":
    main()
