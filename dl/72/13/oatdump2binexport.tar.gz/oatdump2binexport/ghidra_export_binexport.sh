#!/bin/bash
# based on ghidra/support/analyzeHeadless

set -e

HELPMSG="USAGE: $0 <input_binary_fname> <output_binexport_fname>"

# adjust these as needed, important: check the version expected by the binexport plugin. it's usually not the latest
GHIDRADIR="${GHIDRADIR:-~/Desktop/ghidra_11.0.3_PUBLIC}"
SCRIPTPATH=./ghidrascripts
PROJECTLOCATION=./ghidraproject

# big oats need lots of RAM, this should be enough
MAXMEM=32G
# analysis parallelizes well but cpu usage can spike. limit so it doesn't cause slowdowns
THREADS=8

if [ -z "$1" -o -z "$2" ]; then
    echo ${HELPMSG}
    exit 1
fi

INPUT=$1; shift
OUTPUT=$1; shift

PROJECTNAME=`basename ${INPUT}`


echo "Running ghidra headless with the following settings:"
echo " ghidra location:  ${GHIDRADIR}"
echo " project location: ${PROJECTLOCATION}"
echo " name of project:  ${PROJECTNAME}"
echo " threads uses:     ${THREADS}"
echo " memory for jvm:   ${MAXMEM}"
echo " input file:       ${INPUT}"
echo " output file:      ${OUTPUT}"
echo ""
echo -n "Start analysis and export? This might take a while. [y/N] " && read ans && [ ${ans:-N} = y ] || exit 1

mkdir -p ${PROJECTLOCATION}

LAUNCH_MODE=fg
VMARG_LIST="-XX:ParallelGCThreads=${THREADS} -XX:CICompilerCount=${THREADS} "

# Launch HeadlessAnalyzer.
# TODO: if project exists, "-import" fails and "-process" should be used. implementation is left as exercise to the hacker

${GHIDRADIR}/support/launch.sh "${LAUNCH_MODE}" jdk Ghidra-Headless "${MAXMEM}" "${VMARG_LIST}" ghidra.app.util.headless.AnalyzeHeadless \
    "$PROJECTLOCATION" "$PROJECTNAME" \
    -import "${INPUT}" \
    -scriptPath ${SCRIPTPATH} \
    -postScript OatBinExport.java "${OUTPUT}" \
    -preScript DisableGCCAnalyzer.java
