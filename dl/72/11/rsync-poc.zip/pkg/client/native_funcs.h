#ifndef EXPERIMENTAL_CVR_WIP_RSYNC_NATIVE_FUNCS_H_
#define EXPERIMENTAL_CVR_WIP_RSYNC_NATIVE_FUNCS_H_

// Taken from https://github.com/RsyncProject/rsync/blob/9615a2492bbf96bc145e738ebff55bbb91e0bbee/flist.c#L3204
// rsync uses it's own fname_cmp function to sort the file list.
// This is a copy of the function with some modifications
// to make it work with our data structures
int f_name_cmp(
  char *dirname1,
  char *dirname2,
  char *basename1,
  char *basename2,
  int mode1,
  int mode2,
  int protocol_version
);

#endif  // EXPERIMENTAL_CVR_WIP_RSYNC_NATIVE_FUNCS_H_
