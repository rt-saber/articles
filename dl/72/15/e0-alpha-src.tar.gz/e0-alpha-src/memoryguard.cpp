/*
Copyright 2025 Jex Amro (Square Labs LLC)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

/**
 * MemoryGuard
 *
 * A runtime protection module that configures page permissions and
 * manages AArch64 hardware watchpoints to monitor access to untrusted
 * input with efficient, fine-grained precision.
 *
 * Designed for use in dynamic analysis, and Selective Symbolic 
 * Instrumentation on macOS.
 * 
 * Key Features:
 *   - Bitmap-based address tracking (PageMap)
 *   - Dynamic watchpoint assignment
 *   - Recent-access bias for improved coverage
 *   - Stack-aware trimming of local variables
 *   - Support for stepping via temporary unguarding
 */

#include "memoryguard.h"
#include <iostream>
#include <sys/mman.h>
#include <unistd.h>
#include "common.h"


/**
 * Constructor for MemoryGuard.
 *
 * Initializes internal state, retrieves the system page size, and loads
 * the debug register state from the target task.
 *
 * @param mach_target  Pointer to MachTarget for the target process.
 * @param debug        Enables verbose logging if true.
 */
MemoryGuard::MemoryGuard(MachTarget* mach_target, bool debug) : mach_target(mach_target) , debug(debug) {
    pageSize = static_cast<uint64_t>(getpagesize());
    taskGetState();
}

/**
 * Fetch the current ARM debug register state for the target task.
 *
 * Loads the __wvr[n] and __wcr[n] watchpoint state into taskState.
 * Terminates the process if task_get_state fails.
 */
void MemoryGuard::taskGetState() {
  kern_return_t kr;
  mach_msg_type_number_t stateCount = ARM_DEBUG_STATE64_COUNT;
  kr = task_get_state(mach_target->Task(), ARM_DEBUG_STATE64, (thread_state_t)&taskState, &stateCount);
  if (kr != KERN_SUCCESS) {
    FATAL("task_get_state error: %s", mach_error_string(kr));
  }
}

/**
 * Clear all watchpoint register values (__wvr[n] and __wcr[n]).
 *
 * This disables all configured hardware watchpoints in the current
 * taskState. Does not commit the cleared state back to the kernel.
 */
void MemoryGuard::clearTaskState() {
  for(int i = 0; i<4; i++) {
    taskState.__wvr[i] = 0;
    taskState.__wcr[i] = 0;
  }
}

/**
 * Compute the MASK bits for a WCR given a region size.
 *
 * This determines the number of address bits needed to cover
 * the region (for sizes > 8 bytes), and encodes that in bits 28–24.
 *
 * @param size  The region size (must be power of two).
 * @return      Encoded MASK bits (shifted into position).
 */
uint32_t MemoryGuard::wcrMask(uint64_t size) {
    if (size <= 8) return 0;
    uint32_t bits = 0;
    while (size > 1) {
        size >>= 1;
        bits++;
    }
    return bits << 24;
}

/**
 * Generate a WCR (Watchpoint Control Register) value.
 *
 * This constructs a control register value that encodes which bytes
 * to watch (using a byte-select mask), the region size (via MASK),
 * and the common access control flags (read, write, user-mode, enable).
 *
 * @param address  Base address of the watchpoint.
 * @param size     Size of the region (must be power of two).
 * @return         Encoded WCR value.
 */
uint64_t MemoryGuard::wcr(uint64_t address, uint64_t size) {

  uint32_t byte_address_select = 0;
  uint32_t MASK = 0;

  if (size == 1) {
    byte_address_select = 1 << (address & 0x7);
  } else if (size <= 8) {
    byte_address_select = (1 << size) - 1;
    byte_address_select <<= (address & 0x7);
  } else {
    byte_address_select = 0xff;
    MASK = wcrMask(size);
  }

  byte_address_select = byte_address_select << 5;
  uint64_t wcr = byte_address_select | // Which bytes to watch
                                MASK | // MASK
                              S_USER | // Stop only in user mode
                            WCR_LOAD | // Stop on read access?
                           WCR_STORE | // Stop on write access? WCR_STORE
                          WCR_ENABLE;  // Enable this watchpoint;
  return wcr;
}

/**
 * Find the index of a free hardware watchpoint register (__wvr).
 *
 * @return Index of a free slot (0–3), or -1 if all are in use.
 */
int MemoryGuard::getFreeWVR() {

  for(uint8_t wvr_id = 0; wvr_id<4; wvr_id++) {
    if (taskState.__wvr[wvr_id] == 0) return wvr_id;
  }
  return -1;
}

/**
 * Add a memory region to the guard set.
 *
 * This function adds each page overlapping the specified address
 * range to `guardedPages`. For each new page, it stores original
 * protection info and initializes a PageMap for tracking.
 *
 * Then it adds the range to the page’s addressMap, marks the page
 * for watchpoint update, and inserts it into the stepping set.
 *
 * @param address   Start address of the region to guard.
 * @param size      Number of bytes to guard.
 * @param isStack   Whether this region belongs to the stack.
 * @param step      Whether to prepare the page for stepping.
 */
void MemoryGuard::add(uint64_t address, uint32_t size, bool isStack, bool step) {
    uint64_t firstPageStart = address & ~(pageSize - 1);
    uint64_t lastPageEnd = (address + size - 1) & ~(pageSize - 1);
    uint64_t stop_address = address + size;
    
    for (uint64_t page = firstPageStart; page <= lastPageEnd; page = page + pageSize) {
        auto& pageInfo = guardedPages[page];
        if (!pageInfo.isInitialized) {
            mach_vm_address_t region_start = (mach_vm_address_t)page;
            mach_vm_size_t region_size = pageSize;
            vm_region_basic_info_data_t info;
            mach_msg_type_number_t info_count = VM_REGION_BASIC_INFO_COUNT_64;
            mach_port_t object_name;
            
            kern_return_t kr = mach_vm_region(mach_target->Task(), &region_start, &region_size, VM_REGION_BASIC_INFO_COUNT_64, (vm_region_info_t)&info, &info_count, &object_name);
            if (kr == KERN_FAILURE)
                FATAL("mach_vm_region() error\n");

            pageInfo.protection = info.protection;
            pageInfo.isStack = isStack;
            pageInfo.pageBaseAddr = page;
            pageInfo.addressMap.pageBaseAddr = page;
            pageInfo.isInitialized = true;
        }

        // Calculate the range of addresses within this page
        uint64_t rangeStart = std::max(address, page);
        uint64_t rangeEnd = std::min(stop_address, page + pageSize);
        
        // Add the range of addresses to the PageMap
        uint32_t added = pageInfo.addressMap.add(
            rangeStart, 
            static_cast<uint32_t>(rangeEnd - rangeStart)
            );
        
        // Update total guarded count
        totalGuarded += added;
        
        pageInfo.updateWatchpoint = true;
        steppingPages.insert(page);
    }

    hasUpdatedPages = true;
}

/**
 * Remove a region of memory from the guard set.
 *
 * This function removes tracking information for all addresses
 * in the specified range. Pages are deleted from `guardedPages`
 * if they become empty after the removal.
 *
 * @param address  Starting address of the region to remove.
 * @param size     Number of bytes to remove.
 */
void MemoryGuard::remove(uint64_t address, uint32_t size) {
    uint64_t firstPageStart = address & ~(pageSize - 1);
    uint64_t lastPageEnd = (address + size - 1) & ~(pageSize - 1);
    uint64_t stop_address = address + size;
    
    for (uint64_t page = firstPageStart; page <= lastPageEnd; page = page + pageSize) {
        // First check if page exists in guardedPages
        auto it = guardedPages.find(page);
        if (it == guardedPages.end()) continue;
        PageInfo& pageInfo = it->second;
        
        // Calculate the range of addresses within this page
        uint64_t rangeStart = std::max(address, page);
        uint64_t rangeEnd = std::min(stop_address, page + pageSize);
        
        // Remove the range of addresses from the PageMap
        uint32_t removed = pageInfo.addressMap.remove(
            rangeStart, 
            static_cast<uint32_t>(rangeEnd - rangeStart)
            );
        
        // Update total guarded count
        totalGuarded -= removed;
        
        // Check if no more addresses belong to the memory page
        if (pageInfo.addressMap.empty()) {
            removePage(page, pageInfo);
        } else {
            pageInfo.updateWatchpoint = true;
        }
    }
    hasUpdatedPages = true;
}

/**
 * Remove all guarded pages and reset their protections.
 *
 * This function fully clears the guardedPages map, resets the
 * debug register state, and restores original memory protections.
 */
void MemoryGuard::removeAll(){
    for (auto const& [page, pageInfo] : guardedPages) {
        mach_vm_protect(mach_target->Task(), page, pageSize, false, pageInfo.protection);
        totalGuarded -= pageInfo.addressMap.size();
    }
    guardedPages.clear();
    steppingPages.clear();

    clearTaskState();
}

/**
 * Remove a page entirely from the guard set.
 *
 * This restores the original memory protection and erases the
 * page from `guardedPages` and `steppingPages`.
 *
 * @param page      Page base address.
 * @param pageInfo  PageInfo structure for the page.
 */
void MemoryGuard::removePage(uint64_t page, PageInfo &pageInfo) {
    // Restore page protection before removing
    mach_vm_protect(mach_target->Task(), page, pageSize, false, pageInfo.protection);
    
    guardedPages.erase(page);
    steppingPages.erase(page);
    if (page == lastAccessedPage) lastAccessedPage = 0;
}

/**
 * Print the number of tracked addresses in each guarded page.
 *
 * This function iterates through all currently guarded pages and
 * prints the base address and the count of tracked bytes in each
 * page. Output is shown only if debug mode is enabled.
 */
void MemoryGuard::logPagesInfo(){
    for (auto const& [page, pageInfo] : guardedPages) {
        if (debug) LOG("%llx: %u\n",page, pageInfo.addressMap.size());
    }
}

/**
 * Remove local stack variables based on the current stack pointer.
 *
 * This function cleans up addresses below `sp` in the current stack
 * page and fully clears older stack pages up to 1MB below `sp`.
 *
 * Behavior:
 * - In the current stack page: removes addresses below `sp`.
 * - In pages below: removes all addresses entirely.
 *
 * Stack pages are identified using the `isStack` flag in PageInfo.
 *
 * @param sp  The current stack pointer.
 */
void MemoryGuard::removeLocalVariables(uint64_t sp) {
    uint64_t currentStackPage = sp & ~(pageSize - 1);
    uint64_t lowestPage = currentStackPage - (1024 * 1024); // 1MB below
    int removedLocalVariables = 0;
    std::vector<uint64_t> pagesToRemove;
    
    // Single pass through all guarded pages
    for (const auto& entry : guardedPages) {
        uint64_t pageAddr = entry.first;
        const PageInfo& pageInfo = entry.second;
        
        // Skip if not a stack page or if page is above our range
        if (!pageInfo.isStack || pageAddr > currentStackPage || pageAddr < lowestPage) {
            continue;
        }
        
        if (pageAddr == currentStackPage) {

            PageInfo& currentPageInfo = guardedPages[pageAddr];
            
            // Remove all addresses lower than sp in the current page
            uint32_t removed = currentPageInfo.addressMap.removeAddressesLowerThan(sp);
            totalGuarded -= removed;
            removedLocalVariables += removed;
            
            if (removed > 0) {
                currentPageInfo.updateWatchpoint = true;
                hasUpdatedPages = true;
            }
            
            // If addressMap is empty, add to removal list
            if (currentPageInfo.addressMap.empty()) {
                pagesToRemove.push_back(pageAddr);
            }
        } else {
            // For pages below current page, remove everything
            uint32_t removed = pageInfo.addressMap.size();
            totalGuarded -= removed;
            removedLocalVariables += removed;
            pagesToRemove.push_back(pageAddr);
        }
    }
    
    // Remove all identified pages
    for (uint64_t pageAddr : pagesToRemove) {
        removePage(pageAddr, guardedPages[pageAddr]);
        hasUpdatedPages = true;
    }
    
    if (removedLocalVariables && debug) {
        LOG("Removed %d local variable address(es)\n", removedLocalVariables);
    }
}

/**
 * Check if any part of a memory region is guarded.
 *
 * This function checks whether any address in the specified range
 * overlaps with any currently tracked (guarded) address.
 *
 * @param address  Start of the memory range.
 * @param size     Number of bytes to check.
 * @return         True if any address is guarded; false otherwise.
 */
bool MemoryGuard::isGuarded(uint64_t address, uint32_t size) {
    uint64_t firstPageStart = address & ~(pageSize - 1);
    uint64_t lastPageEnd = (address + size - 1) & ~(pageSize - 1);
    uint64_t stop_address = address + size;

    if (lastPageEnd < firstPageStart)
        FATAL("lastPageEnd < firstPageStart");
    
    // Check each page that overlaps with the range
    for (uint64_t page = firstPageStart; page <= lastPageEnd; page += pageSize) {
        auto it = guardedPages.find(page);
        if (it == guardedPages.end()) {
            // todo: move memAccess() logic here
            continue;
        }
        
        PageInfo& pageInfo = it->second;
        
        // Calculate the range to check within this page
        uint64_t rangeStart = std::max(address, page);
        uint64_t rangeEnd = std::min(stop_address, page + pageSize);

        if (rangeEnd < rangeStart)
            FATAL("rangeEnd < rangeStart");
        
        // Use PageMap's range checking capability
        if (pageInfo.addressMap.hasAddress(rangeStart, static_cast<uint32_t>(rangeEnd - rangeStart))) {
            if (debug) LOG("%016llx is Guarded\n", rangeStart);
            // no need to keep track of recently guarded access
            // pageInfo.recentlyAccessedAddress = 0;
            return true;
        }
        
        // for debugging
        // for (uint64_t addr = rangeStart; addr < rangeEnd; addr++) {
        //     if (pageInfo.addressMap.hasAddress(addr, 1))
        //         FATAL("Failed a guard check on %llx", addr);
        // }
    }
    
    if (debug) LOG("%llx[%u] is not Guarded\n", address, size);
    return false;
}

/**
 * Check if any page overlapping a memory range is guarded.
 *
 * This function simply tests whether any page overlapping the
 * specified range is present in the guardedPages map.
 *
 * This is faster than isGuarded() but less precise.
 *
 * @param address  Start of the memory range.
 * @param size     Number of bytes.
 * @return         True if any page is guarded.
 */
bool MemoryGuard::isGuardedAccess(uint64_t address, uint32_t size) {
    // remove highest 4 bits as 800000010200bc04 would match 10200bc04
    address = address & 0x0FFFFFFFFFFFFFFF;
    uint64_t firstPageStart = address & ~(pageSize - 1);
    uint64_t lastPageEnd = (address + size - 1) & ~(pageSize - 1);
    uint64_t stop_address = address + size;
    
    // Check each page that overlaps with the range
    for (uint64_t page = firstPageStart; page <= lastPageEnd; page += pageSize) {
        if (guardedPages.find(page) != guardedPages.end()) return true;
    }
    if (debug) LOG("%llx[%u] is not Guarded\n", address, size);
    return false;
}

/**
 * Temporarily unprotect page(s) to step over a faulting access.
 *
 * Restores memory protections to allow execution to proceed,
 * typically after a watchpoint trap. Only affects pages currently
 * in the guardedPages set.
 *
 * @param address  Address causing the fault.
 * @param size     Instruction size (default 4 or 8).
 */
void MemoryGuard::step(uint64_t address, uint32_t size) {
    
    uint64_t firstPageStart = address & ~(pageSize - 1);
    uint64_t lastPageEnd = (address + size - 1) & ~(pageSize - 1);
    
    for (uint64_t page = firstPageStart; page <= lastPageEnd; page = page + pageSize) {
        if (steppingPages.find(page) != steppingPages.end())
            continue;
        if (guardedPages.find(page) != guardedPages.end()) {
            mach_vm_protect(mach_target->Task(), page, pageSize, false, guardedPages[page].protection); //VM_PROT_DEFAULT);
            steppingPages.insert(page);
        }
    }
}

/**
 * Check if a given address falls within a guarded page.
 *
 * This function checks both the aligned page and the adjacent
 * 32-byte boundary-crossing page (for unaligned memory access).
 *
 * @param address  Address to check.
 * @return         True if address is within any guarded page.
 */
bool MemoryGuard::isGuardedPage(uint64_t address) {
    uint64_t firstPage = address & ~(pageSize - 1);
    uint64_t secondPage = (address + 31) & ~(pageSize - 1);
    if (guardedPages.find(firstPage) != guardedPages.end())
        return true;
    if (firstPage != secondPage) {
        if (guardedPages.find(secondPage) != guardedPages.end())
            return true;
    }
    return false;
}

/**
 * Remove protections from all tracked pages.
 *
 * This function disables memory protections across all pages in
 * guardedPages by setting them to no-access. This prepares them
 * for the next instrumentation step (e.g., reprogramming WPs).
 */
void MemoryGuard::unguardAllPages() {
    for (const auto& [pageStartAddr, pageInfo] : guardedPages) {
        if (debug) LOG("unguarding page %llx\n", pageStartAddr);
        mach_vm_protect(mach_target->Task(), pageStartAddr, pageSize, false, guardedPages[pageStartAddr].protection); //VM_PROT_DEFAULT);
        steppingPages.insert(pageStartAddr);
    }
    stepping = true;
}

/**
 * Reapply protections and reconfigure hardware watchpoints.
 *
 * This function reestablishes memory protections and programs
 * the ARM debug registers using the latest tracked data.
 *
 * Prioritizes the most recently accessed page and emits either:
 * - a single main watchpoint
 * - multiple split watchpoints (up to 4)
 *
 * For other pages, fallback protection is applied if no WP fits.
 */
void MemoryGuard::guardAllPages() {
    
    if (!stepping) FATAL("Not Stepping!");

    int wvr_id = 0;

    //lastAccessedPage = 0;

    if (lastAccessedPage) {
        if (guardedPages.find(lastAccessedPage) != guardedPages.end()) {
            
            auto& pageInfo = guardedPages[lastAccessedPage];
            if (pageInfo.numSplitWatchpoints) {
                
                if (debug) LOG("guarding page %llx | splits: %zu | mainWatchpoint: %llx|%llu [last accessed and has splits]\n", 
                    lastAccessedPage, 
                    pageInfo.numSplitWatchpoints,
                    pageInfo.watchpoint.address,
                    pageInfo.watchpoint.size);
                
                if ((!pageInfo.watchpoint.address) || (!pageInfo.watchpoint.wcr))
                    FATAL("no wp conf");

                for (int i = 0; i < pageInfo.numSplitWatchpoints; ++i) {
                    if (debug) {
                        LOG("    - @taskState.__wvr[%d] %llx|%llu\n", 
                            wvr_id, 
                            pageInfo.watchpointSplits[i].address, 
                            pageInfo.watchpointSplits[i].size);
                    }
                    taskState.__wvr[wvr_id] = pageInfo.watchpointSplits[i].address;
                    taskState.__wcr[wvr_id] = pageInfo.watchpointSplits[i].wcr;
                    wvr_id++;
                }
                if (debug) {
                    LOG("      recentAccessAddress: %llx\n", pageInfo.recentlyAccessedAddress);
                    LOG("        page addressCount: %d\n", pageInfo.addressMap.size());
                }
                //pageInfo.addressMap.printAddresses();
            } else {
                if (debug) LOG("guarding page %llx @taskState.__wvr[%d] %llx|%llu\n", 
                    lastAccessedPage, 
                    wvr_id,
                    pageInfo.watchpoint.address,
                    pageInfo.watchpoint.size);
                if ((!pageInfo.watchpoint.address) || (!pageInfo.watchpoint.wcr))
                    FATAL("no wp conf");
                taskState.__wvr[wvr_id] = pageInfo.watchpoint.address;
                taskState.__wcr[wvr_id] = pageInfo.watchpoint.wcr;
                wvr_id += 1;
            }
        } else {
          LOG(RED"lastAccessedPage %llx not found!\n", lastAccessedPage);
          lastAccessedPage = 0;
        }
    }

    for (auto& [pageStartAddr, pageInfo] : guardedPages) {
        
        if (pageStartAddr == lastAccessedPage) continue;

        if ((wvr_id >= 4) || (!pageInfo.watchpoint.wcr) || (pageInfo.watchpoint.size == 16384)) {
            if (debug) LOG("guarding page %llx\n", pageStartAddr);
            mach_vm_protect(mach_target->Task(), pageStartAddr, pageSize, false, VM_PROT_NONE);
            continue;
        }

        if (debug) LOG("guarding page %llx @taskState.__wvr[%d] %llx|%llu\n", 
            pageStartAddr, 
            wvr_id,
            pageInfo.watchpoint.address,
            pageInfo.watchpoint.size);
        if ((!pageInfo.watchpoint.address) || (!pageInfo.watchpoint.wcr))
            FATAL("no wp conf");
        taskState.__wvr[wvr_id] = pageInfo.watchpoint.address;
        taskState.__wcr[wvr_id] = pageInfo.watchpoint.wcr;
        wvr_id += 1;
    }
    steppingPages.clear();
    stepping = false;
}

/**
 * Reapply no-access protections to all stepped pages.
 *
 * Called after instruction-level stepping has finished. Pages in
 * `steppingPages` are protected again with VM_PROT_NONE to resume
 * trap-based monitoring.
 */
void MemoryGuard::protectSteppingPages() {
    
    if (steppingPages.empty()) {
        WARN("SteppingPages is empty");
        return;
    }
    for (const auto& page : steppingPages) {
        mach_vm_protect(mach_target->Task(), page, pageSize, false, VM_PROT_NONE);
    }
    steppingPages.clear();
    if (steppingPages.size())
        FATAL("failed to clear steppingPages");
}


/**
 * Check whether a page has been recently accessed.
 *
 * This function searches the internal recentPages queue to see
 * if the specified page is currently marked as recently accessed.
 *
 * @param page  Page base address (aligned to page size).
 * @return      True if the page is in the recentPages queue.
 */
bool MemoryGuard::isPageRecentlyAccessed(uint64_t page) const {
    for (const auto& p : recentPages) {
        if (p == page) {
            return true;
        }
    }
    return false;
}

/**
 * Mark a page as recently accessed and update tracking order.
 *
 * This function maintains a fixed-size MRU queue of up to 4 pages.
 * When a page is accessed:
 * - If already in the queue: it's moved to the front.
 * - If not: it's inserted, and the oldest entry is dropped if full.
 *
 * Also updates flags in `guardedPages` to reflect recent access.
 *
 * @param page  Base address of the accessed page.
 */
void MemoryGuard::pageAccess(uint64_t page) {
    // Always update lastAccessedPage
    lastAccessedPage = page;
    
    // Check if page is already in our tracking by 
    // iterating once through the queue
    bool pageFound = false;
    auto it = recentPages.begin();
    
    while (it != recentPages.end()) {
        if (*it == page) {
            // Found the page in queue, remove it from current position
            it = recentPages.erase(it);
            pageFound = true;
            break;
        }
        ++it;
    }
    
    // If page wasn't found and queue is full, remove the oldest page
    if (!pageFound && recentPages.size() >= maxAccessPages) {
        uint64_t oldestPage = recentPages.back();
        recentPages.pop_back();
        
        // Mark it as not recently accessed
        if (guardedPages.find(oldestPage) != guardedPages.end()) {
            guardedPages[oldestPage].recentlyAccessed = false;
        }
    }
    
    // Add the page to the front (most recent)
    recentPages.push_front(page);
    
    // Mark the page as recently accessed
    guardedPages[page].recentlyAccessed = true;
    
    if (debug) debugPrintRecentlyAccessedPages();
}

/**
 * Print the list of recently accessed pages in MRU order.
 *
 * Outputs each tracked page along with flags such as:
 * - (last accessed)
 * - (stack) — if marked as a stack page
 */
void MemoryGuard::debugPrintRecentlyAccessedPages() {
    std::cout << "Recent pages (newest to oldest):" << std::endl;
    
    if (recentPages.empty()) {
        std::cout << "  No pages accessed yet." << std::endl;
        return;
    }
    
    int i = 1;
    for (const auto& page : recentPages) {
        std::cout << "  " << i << ". 0x" << std::hex << page << std::dec;
        
        if (page == lastAccessedPage) {
            std::cout << " (last accessed)";
        }
        if (guardedPages.find(page) != guardedPages.end() && guardedPages[page].isStack) {
            std::cout << " (stack)";
        }
        
        std::cout << std::endl;
        i++;
    }
    
    std::cout << "Total unique pages tracked: " << recentPages.size() << std::endl;
}

/**
 * Handle a memory access event at the given address.
 *
 * This function tracks the page as recently accessed. If the address
 * is not already tracked in the page’s address map, the page is marked
 * for watchpoint update and the address is stored for biasing.
 *
 * @param address  The address that was accessed.
 */
void MemoryGuard::memAccess(uint64_t address) {
  // todo: what if mem access is hitting two pages?
  uint64_t page = address & ~(pageSize - 1);

  // first check if the memAccess is in one of of the guarded pages
  // if not, then it might be related to bad access (crash)
  if (guardedPages.find(page) == guardedPages.end()) {
    uint64_t guarded_page = page&0xFFFFFFFFFFFF;
    if (guardedPages.find(guarded_page) != guardedPages.end()) {
        // guarding 0x10480ce00 but got 0x800000010480ce00
        // as wp doesn't check high bits!
        // to eliminate many wp hits, we simply remove 0x10480ce00 wp
        // by setting recentlyAccessed to false
        guardedPages[guarded_page].recentlyAccessed = false;
        //recentPageAccessSet.erase(guarded_page);
    } else {
      LOG(RED"[MemoryGuard::memAccess] got bad access @%llx\n", address);
    }
    return;
  }

  pageAccess(page);

  auto& pageInfo = guardedPages[page];
  // updatePageSplitWatchpoints if address is not guarded.
  if (!pageInfo.addressMap.hasAddress(address)) {
    // Set page recentlyAccessedAddress
    pageInfo.recentlyAccessedAddress = address;
    pageInfo.updateWatchpoint = true;
    hasUpdatedPages = true;
  } else {
    pageInfo.recentlyAccessedAddress = 0;
  }
}

/**
 * Update a page's main watchpoint using PageMap configuration.
 *
 * Clears all split watchpoints and resets the recently accessed
 * address field for the page.
 *
 * @param pageInfo  The PageInfo structure to update.
 */
void MemoryGuard::updatePageWatchpoint(PageInfo& pageInfo) {
    if (debug) LOG("[updatePageWatchpoint] @%llx\n", pageInfo.pageBaseAddr);
    pageInfo.addressMap.computeWatchpoint(pageInfo.watchpoint);
    pageInfo.numSplitWatchpoints = 0;
    pageInfo.recentlyAccessedAddress = 0;
}

/**
 * Update a page's split watchpoints using PageMap configuration.
 *
 * This is used when a page has a known recently accessed address
 * that should bias the recursive splitting process.
 *
 * @param pageInfo  The PageInfo structure to update.
 */
void MemoryGuard::updatePageSplitWatchpoints(PageInfo& pageInfo) {
    if (debug) LOG("[updatePageSplitWatchpoints] @%llx\n", pageInfo.pageBaseAddr);
    pageInfo.numSplitWatchpoints = pageInfo.addressMap.computeWatchpointSplits(
        pageInfo.watchpoint,
        pageInfo.watchpointSplits,
        pageInfo.recentlyAccessedAddress);
}

/**
 * Apply watchpoint updates to all pages marked for update.
 *
 * For each page that has updateWatchpoint == true, either its main
 * or split watchpoints are recalculated, depending on whether it
 * has a recently accessed address set.
 */
void MemoryGuard::updateWatchpoints() {

    if (debug) LOG("[updateWatchpoints]\n");
    for (auto& [pageStartAddr, pageInfo] : guardedPages) {   
        
        if (pageInfo.updateWatchpoint) {
            if (pageInfo.recentlyAccessedAddress) {
                updatePageSplitWatchpoints(pageInfo);
            } else {
                updatePageWatchpoint(pageInfo);
            }
            pageInfo.updateWatchpoint = false;
            if (debug) LOG("[+] %llx: %llx[%lld] split: %zu\n", 
                pageStartAddr, 
                pageInfo.watchpoint.address, 
                pageInfo.watchpoint.size,
                pageInfo.numSplitWatchpoints);

            // for (const auto& address : pageInfo.addresses){
            //     LOG("%llx\n", address);
            // }
        } else {
            if (debug) LOG("[-] %llx: %llx[%lld] split: %zu\n", 
                pageStartAddr, 
                pageInfo.watchpoint.address, 
                pageInfo.watchpoint.size,
                pageInfo.numSplitWatchpoints);
        }
    }
    hasUpdatedPages = false;
}