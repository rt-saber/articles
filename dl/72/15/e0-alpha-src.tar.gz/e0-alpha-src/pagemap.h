/*
Copyright 2025 Jex Amro (Square Labs LLC)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

/**
 * PageMap - Hierarchical bitmap tracker for 16KB pages
 *
 * Tracks an arbitrary set of bytes inside a 16KB page using a compact
 * three-level bitmap hierarchy:
 *
 *     Root -> Segments -> Qwords -> Bytes
 *
 * This layout enables fine-grained tracking while supporting efficient
 * watchpoint placement using only four hardware slots on AArch64. It
 * enables Selective Symbolic Instrumentation and precise memory analysis
 * under constrained hardware conditions.
 *
 * Level 1 (root): A 32-bit root bitmap marks which 512B segments contain
 *                 any tracked byte. There are 32 segments per 16KB page.
 *
 * Level 2 (segments): For each set bit in the root, a 64-bit segment mask
 *                     identifies which 8-byte qwords within the 512B
 *                     segment are active (64 qwords per segment).
 *
 * Level 3 (qwords): For each active qword, an 8-bit mask specifies which
 *                   individual bytes are being tracked (1 bit per byte).
 *                   We terminate the refinement process at the qword level
 *                   because, at this granularity, the ARM CPU supports a
 *                   byte-select mask that allows us to monitor only the
 *                   specific bytes of interest within the aligned 8-byte
 *                   region.
 *
 * PageMap also supports a Strict Recent Access Bias policy: if a specific
 * memory access is known to have triggered a fault, splitting is biased
 * toward the region containing that address. This improves precision and
 * watchpoint reuse under high contention.
 *
 * This recursive layout supports:
 * - Fast queries for guarded addresses
 * - Efficient insertion/removal of address ranges
 * - Optimal watchpoint placement based on locality
 *
 * Designed for integration with page protection logic and dynamic
 * watchpoint configuration on macOS AArch64 systems.
 */

#ifndef PAGEMAP_H
#define PAGEMAP_H

#include <cstdint>
#include <vector>
#include <utility>
#include "watchpoint.h"
#include <iostream>
#include <bitset>

// Watchpoint and breakpoint control constants
#define S_USER ((uint32_t)(2u << 1))
#define BCR_ENABLE ((uint32_t)(1u))
#define WCR_ENABLE ((uint32_t)(1u))
#define WCR_LOAD ((uint32_t)(1u << 3))
#define WCR_STORE ((uint32_t)(1u << 4))
#define MDE_ENABLE ((uint32_t)(1u << 15))
#define SS_ENABLE ((uint32_t)(1u))

// rootBitmap-level work
struct RootWork {
    uint32_t bits;
    uint32_t startPos;
    uint32_t width;
    size_t size;
    size_t reductionRate;
};

// Segment-level work
struct SegmentWork {
    uint64_t bits;
    uint32_t startPos;
    uint32_t width;
    uint32_t size;
};

class PageMap {
private:
    /** Size of the page in bytes (fixed at 16 KB). */
    static constexpr size_t PAGE_SIZE = 16384;

    /** Size of a qword (8 bytes per tracked block). */
    static constexpr size_t QWORD_SIZE = 8;

    /** Total number of qwords in the page (2048 = 16 KB / 8 B). */
    static constexpr size_t NUM_QWORDS = PAGE_SIZE / QWORD_SIZE;

    /** Total number of segments (32 = 2048 qwords / 64 qwords per segment). */
    static constexpr size_t NUM_SEGMENTS = NUM_QWORDS / 64;

    /** Total number of tracked bytes currently set in the bitmap. */
    uint32_t addressCount;

    /** Root-level bitmap: 1 bit per 512-byte segment (32 total). */
    uint32_t rootBitmap;

    /** Segment-level bitmaps: 64 bits per segment, 32 segments total. */
    uint64_t pageSegments[NUM_SEGMENTS];

    /** Byte-level tracking: one 8-bit mask per 8-byte qword. */
    uint8_t pageQwords[NUM_QWORDS];

    /**
     * Root-level bitmask with a 1-bit set at the index of the most 
     * recently accessed segment. Used to bias root-level splits. 
     * Zero if not known.
     */
    mutable uint32_t recentSegmentBit = 0;

    /** Index of the most recently accessed segment (0–31), 
     * or -1 if invalid. 
     */
    mutable uint32_t recentSegmentIndex = -1;

    /**
     * Segment-level bitmask with a 1-bit set at the index of the most 
     * recently accessed qword within its segment (bit 0–63). 
     * Used to bias segment splits.
     */
    mutable uint64_t recentQwordBit = 0;

    /**
     * Return the qword index corresponding to a given address.
     *
     * This computes which of the 2048 8-byte qwords in the 16 KB
     * page contains the specified address.
     *
     * @param addr  Address within the page.
     * @return      Index of the qword (0–2047).
     */
    static inline uint32_t getQwordIndex(uint64_t addr);

    /**
     * Return the byte offset within a qword for a given address.
     *
     * This computes the position of the byte within its enclosing
     * 8-byte qword. The result is always in the range 0–7.
     *
     * @param addr  Address within the page.
     * @return      Byte offset within the qword (0–7).
     */
    static inline uint8_t getByteOffsetInQword(uint64_t addr);

    /**
     * Mark the segment and root bit for the specified qword.
     *
     * This function sets the appropriate bit in the segment mask
     * and in the root bitmap to indicate that the given qword now
     * contains at least one tracked byte.
     *
     * This must be called whenever a qword transitions from empty
     * to non-empty.
     *
     * @param qwordIndex  Index of the qword (0–2047) to mark.
     */
    inline void markQwordSet(uint32_t qwordIndex);

    /**
     * Generate a bitmask covering a byte range within a qword.
     *
     * Produces an 8-bit mask with bits set from startOffset to
     * endOffset (inclusive). Used to isolate or update specific
     * byte positions within an 8-byte qword.
     *
     * Example:
     *   byteMask(2, 5) → 0b00111100
     *
     * @param startOffset  Start byte position (0–7).
     * @param endOffset    End byte position (0–7).
     * @return             8-bit mask with selected bits set.
     */
    inline uint8_t byteMask(uint8_t startOffset, uint8_t endOffset) const;
    
    /**
     * Clear segment and root bits if the qword becomes empty.
     *
     * If the specified qword no longer tracks any bytes, this
     * function clears its bit in the corresponding segment mask.
     * If the entire segment becomes empty as a result, the root
     * bitmap is updated to reflect that as well.
     *
     * @param qwordIndex  Index of the qword (0–2047) to check.
     */
    inline void unmarkQwordIfEmpty(uint32_t qwordIndex);

    /**
     * Compute the Watchpoint Control Register (WCR) value.
     *
     * This function generates a WCR bitfield that controls a hardware
     * watchpoint. It encodes the size, access type (read/write), user 
     * mode, and an optional byte-select mask.
     *
     * For small regions (≤ 8 bytes):
     * - The byte-select mask is provided explicitly via qword_content.
     *   Each bit represents one byte within the 8-byte aligned qword.
     *
     * For larger regions (> 8 bytes):
     * - A full 0xFF byte mask is used.
     * - The size is encoded using the highest set bit position.
     *
     * The result also includes common bits:
     * - WCR_LOAD and WCR_STORE to trigger on read and write
     * - S_USER to restrict to user-mode accesses
     * - WCR_ENABLE to activate the watchpoint
     *
     * @param size            Size of the watchpoint in bytes.
     * @param qword_content   Byte mask for ≤8-byte watchpoints 
     *                        (default 0).
     * @return                Encoded 32-bit WCR value.
     */
    static uint64_t wcr(uint64_t size, uint8_t qword_content = 0);

public:
    /** Page base address */
    uint64_t pageBaseAddr;

    /**
     * Initialize a new PageMap with all bits cleared
     */
    PageMap();

    /**
     * Return the number of tracked byte addresses in the page.
     *
     * This reflects the total count of individual bytes currently
     * marked as active in the bitmap, across all qwords.
     *
     * @return  Number of tracked bytes.
     */
    uint32_t size() const;

    /**
     * Check whether the page map is currently empty.
     *
     * Returns true if no addresses are being tracked. This is
     * equivalent to checking whether the address count is zero.
     *
     * @return  True if no bytes are tracked; false otherwise.
     */
    bool empty() const;

    /**
     * Check whether any byte in the given range is being tracked.
     *
     * For a single address (size == 1), this checks whether the
     * corresponding byte bit is set in the target qword.
     *
     * For larger ranges:
     * - The first and last qwords are checked using partial masks.
     * - Any qword in between is checked for non-zero bits.
     *
     * The function returns true if at least one byte in the range
     * is currently tracked. It does not require full coverage.
     *
     * @param addr   Starting address to check.
     * @param size   Number of bytes to check.
     * @return       True if any byte in the range is tracked.
     */
    bool hasAddress(uint64_t addr, uint32_t size = 1) const;

    /**
     * Add an address or address range to the tracked set.
     *
     * For a single address (size == 1), the function sets the
     * corresponding byte bit in the qword, and updates the
     * segment and root bitmaps if this is the first tracked byte
     * in that qword.
     *
     * For larger ranges:
     * - The first and last qwords are updated with partial byte
     *   masks.
     * - All fully covered qwords in the middle are set to 0xFF.
     * - Each qword added updates its corresponding segment and
     *   root bitmap bits.
     *
     * The total number of newly tracked bytes is returned.
     *
     * @param addr   Starting address to add.
     * @param size   Number of bytes to track.
     * @return       Number of bytes newly added.
     */
    uint32_t add(uint64_t addr, uint32_t size = 1);

    /**
     * Remove a tracked address or address range from the page map.
     *
     * For a single address (size == 1), the function checks whether
     * the corresponding byte is set. If so, it clears that byte and
     * updates the segment and root bitmaps if the qword becomes empty.
     *
     * For larger ranges:
     * - It handles the first and last qwords with partial byte masks.
     * - Any full qwords in between are cleared entirely.
     * - Segment and root bits are cleared when qwords become empty.
     *
     * If a segment is known to be inactive, the function skips it for
     * performance.
     *
     * @param addr   Starting address to remove.
     * @param size   Number of bytes to remove.
     * @return       Number of bytes that were actually removed.
     */
    uint32_t remove(uint64_t addr, uint32_t size = 1);

    /**
     * Remove all addresses below a given threshold.
     *
     * This function deletes every tracked byte whose address is less
     * than the specified target address. It operates efficiently by:
     * - Clearing entire segments that are fully below the threshold.
     * - Partially clearing qwords in the boundary segment.
     *
     * The segment and rootBitmap bits are updated accordingly to
     * maintain consistency.
     *
     * @param addr   Address threshold; all lower addresses are removed.
     * @return       Number of addresses that were removed.
     */
    uint32_t removeAddressesLowerThan(uint64_t addr);

    /**
     * Find and return all continuous groups of tracked addresses.
     *
     * This function walks the full bitmap hierarchy and collects
     * contiguous ranges of addresses where at least one byte is
     * being tracked. Each group is represented as a pair:
     *   { start address, size in bytes }
     *
     * Groups are formed by walking qwords in order and merging
     * adjacent tracked bytes. A new group starts whenever a gap
     * is encountered between tracked addresses.
     *
     * @return  Vector of (start, size) pairs for each address group.
     */
    std::vector<std::pair<uint64_t, uint32_t>> findGroups() const;

    /**
     * Return a list of byte offsets tracked in the given qword.
     *
     * This function checks if the qword is active (its segment bit is
     * set), and if so, examines the corresponding byte mask to find
     * which individual bytes (0–7) are currently being tracked.
     *
     * The result is a list of byte offsets within that 8-byte qword.
     * If the qword is inactive, an empty list is returned.
     *
     * @param qwordIndex  Index of the qword (0–2047) in the page.
     * @return            Vector of byte offsets (0–7) that are set.
     */
    std::vector<uint8_t> getUsedByteOffsetsInQword(uint32_t qwordIndex) const;
    
    /**
     * Return the lowest tracked address in the page.
     *
     * This function searches the bitmap hierarchy from top to bottom:
     * - It scans the rootBitmap for the first active segment.
     * - Then finds the first active qword in that segment.
     * - Then locates the first active byte in that qword.
     *
     * The result is the lowest address currently being tracked in this
     * page. If no addresses are tracked, UINT64_MAX is returned.
     *
     * @return  The lowest tracked address, or UINT64_MAX if empty.
     */
    uint64_t getLowestAddress() const;

    /**
     * Return the highest tracked address in the page.
     *
     * This function scans the bitmap hierarchy in reverse:
     * - It starts from the last segment in rootBitmap and searches
     *   backward for the highest active segment.
     * - Then finds the last active qword in that segment.
     * - Then locates the highest active byte in that qword.
     *
     * The result is the highest address currently being tracked in
     * this page. If no addresses are tracked, UINT64_MAX is returned.
     *
     * @return  The highest tracked address, or UINT64_MAX if empty.
     */
    uint64_t getHighestAddress() const;

    /**
     * Populate a watchpoint structure with address, size, and WCR.
     *
     * This function sets the fields of the given Watchpoint:
     * - `address`: the aligned base address of the watchpoint
     * - `size`: the power-of-two size to cover
     * - `wcr`: a control register value encoding access mode and byte mask
     *
     * If the size is ≤ 8 bytes, the function computes a byte-select mask
     * using the tracked byte state of the corresponding qword. This 
     * enables precise byte-granular watchpoints for small spans.
     *
     * For larger sizes, a full mask is used, and only alignment and size
     * are encoded in the WCR.
     *
     * @param[out] wp    Watchpoint structure to populate.
     * @param addr       Starting address of the watchpoint.
     * @param size       Size of the watchpoint (must be power of two).
     */
    inline void emitWatchpoint(Watchpoint& wp, uint64_t addr, uint64_t size) const;

    /**
     * Recursively find and emit the optimal watchpoint for a bit range.
     *
     * This function searches for the smallest aligned power-of-two span
     * that fully covers all active bits within a range of the root bitmap
     * (32 bits, one bit per 512-byte segment).
     *
     * It recursively divides the range into low and high halves. If only
     * one half contains active bits, the other is discarded and the search
     * continues on the active half. This continues until both halves are
     * active or the width becomes 1.
     *
     * Once the minimal span is found, a watchpoint is emitted. If the span
     * is exactly one segment wide, the qword-level bitmap is further 
     * refined using refineSegmentWatchpoint() for higher precision.
     *
     * @param bits       Root bitmap bits (1 bit per 512B segment).
     * @param startPos   Start bit index in the bitmap (0–31).
     * @param width      Number of bits to evaluate from startPos.
     * @param[out] wp    Watchpoint structure to populate.
     */
    void findOptimalWatchpoint(uint32_t bits, uint32_t startPos, 
        uint32_t width, Watchpoint& wp) const;

    /**
     * Recursively compute watchpoint splits for the root bitmap.
     *
     * This function operates at the root bitmap level (32 bits), where
     * each bit represents a 512-byte segment in the 16 KB page. It
     * identifies up to `maxWatchpoints` optimal watchpoints that cover
     * all active segments with minimal over-approximation.
     *
     * The algorithm proceeds as follows:
     * - Begin with a RootWork structure describing the active range.
     * - If the refined range covers one segment, delegate to
     *   findSegmentLevelSplits().
     * - Otherwise, divide the region into low and high halves. Each
     *   half is refined using refineRootSplit() to reduce unnecessary 
     *   span.
     *
     * A strict recent-access bias is applied:
     * - If the recently accessed segment lies in one half, that half is
     *   given priority and up to (maxWatchpoints - 1); the other half is
     *   limited to a single watchpoint.
     *
     * Recursion continues until no further refinement is possible or the
     * watchpoint budget is exhausted. If splitting fails, a fallback
     * watchpoint is emitted to cover the remaining range.
     *
     * @param bits            Active bits in the root bitmap.
     * @param startPos        Starting bit index in the root bitmap.
     * @param width           Number of bits to process from startPos.
     * @param[out] splits     Output array of up to 4 watchpoints.
     * @param currentSplit    Index into the splits array to write to.
     * @param maxWatchpoints  Maximum number of watchpoints allowed.
     * @return                Total number of watchpoints emitted.
     */
    size_t findRootLevelSplits(
        uint32_t bits, 
        uint32_t startPos, 
        uint32_t width,
        Watchpoint (&splits)[4], 
        size_t currentSplit, 
        size_t maxWatchpoints
    ) const;

    /**
     * Refine a root-level bitmap range to its minimal active span.
     *
     * This function takes a RootWork object describing a subrange of the
     * root bitmap (32 bits, one bit per 512-byte segment), and narrows
     * it by repeatedly discarding empty low or high halves.
     *
     * At each step, if one half of the bitmask is entirely zero, that
     * half is discarded and the remaining half becomes the new active
     * range. This continues until both halves contain bits or the width
     * is reduced to 1.
     *
     * After refinement:
     * - startPos and width are updated to reflect the active range.
     * - size is set to the byte span (width * 512).
     *
     * This process helps ensure subsequent watchpoint calculations are
     * limited to only the active portion of the bitmap.
     *
     * @param[in,out] work  RootWork structure to be refined in place.
     */
    void refineRootSplit(RootWork& work) const;

    /**
     * Refine a segment-level bit range to its minimal active span.
     *
     * This function operates on a 64-bit segment mask, where each bit
     * represents an 8-byte qword in a 512-byte segment. It iteratively
     * discards empty low or high halves until both sides contain bits or
     * the width is reduced to 1.
     *
     * After refinement:
     * - startPos and width are updated to reflect the narrowed range.
     * - size is set to the byte span (width * 8).
     *
     * This ensures that any follow-up watchpoint computation
     * operates on the tightest possible qword range.
     *
     * @param[in,out] work  SegmentWork structure to be refined in place.
     */
    void refineSegmentSplit(SegmentWork& work) const;

    /**
     * Refine a coarse watchpoint within a segment to minimize coverage.
     *
     * This function operates on a single 512-byte segment, using its
     * 64-bit qword bitmap to find the smallest aligned span of active
     * qwords. It iteratively discards empty low or high halves until the
     * remaining range contains active qwords on both sides or reaches a
     * width of 1.
     *
     * Once refined, it emits a watchpoint that covers only the active
     * portion of the segment. For small spans (≤ 8 bytes), a byte-select
     * mask is automatically applied.
     *
     * This is typically used after selecting a segment to watch, in order
     * to reduce false traps caused by over-coverage.
     *
     * @param segmentIndex  Index of the 512-byte segment (0–31).
     * @param[out] wp       Watchpoint structure to populate.
     */
    void refineSegmentWatchpoint(uint32_t segmentIndex, Watchpoint& wp) const;

    /**
     * Recursively split a 64-bit segment to compute precise watchpoints.
     *
     * This function operates at the segment level (64 qwords = 512 bytes),
     * where each bit in the 64-bit mask represents one 8-byte qword. It
     * recursively refines and splits the active range into smaller 
     * regions, emitting watchpoints that tightly cover all active bits.
     *
     * The algorithm proceeds as follows:
     * - Start with a SegmentWork structure describing the segment range.
     * - Refine the range using refineSegmentSplit() to remove unused 
     *   space.
     * - If further splitting is allowed, divide the region into low and
     *   high halves, and allocate watchpoint budget accordingly.
     *
     * A strict recent-access bias is applied:
     * - If recentQwordBit intersects the low half, it receives priority
     *   and up to (maxWatchpoints - 1); the other half is limited to 1.
     *
     * If no further refinement is possible, or budget is exhausted, a
     * fallback watchpoint is emitted to cover the refined region.
     *
     * @param segmentIndex    Index of the segment in the page (0–31).
     * @param work            SegmentWork object defining the bit range.
     * @param[out] splits     Output array of up to 4 watchpoints.
     * @param currentSplit    Index into the splits array to write to.
     * @param maxWatchpoints  Maximum number of watchpoints allowed.
     * @return                Total number of watchpoints emitted.
     */
    size_t findSegmentLevelSplits(
        uint32_t segmentIndex,
        SegmentWork& work,
        Watchpoint (&splits)[4],
        size_t currentSplit,
        size_t maxWatchpoints
    ) const;

    /**
     * Compute optimal watchpoint configuration for tracked addresses.
     *
     * Uses the bitmap hierarchy to efficiently determine the smallest
     * possible single watchpoint that covers all tracked addresses in
     * the page.
     *
     * The function analyzes the bitmap levels in order:
     * root -> segments -> qwords -> bytes, to determine the optimal
     * watchpoint size and alignment.
     *
     * It includes fast paths for:
     * - Single-byte tracking
     * - Multiple bytes within one qword (≤ 8 bytes)
     * - Larger ranges requiring full aligned coverage
     *
     * @param[out] watchpoint  Reference to the Watchpoint structure
     *                         to be populated with the result.
     */
    void computeWatchpoint(Watchpoint& watchpoint) const;

    /**
     * Compute optimal watchpoint splits for tracked addresses in the page.
     *
     * This function computes a main watchpoint that covers all tracked
     * addresses, then decides whether to refine that into smaller regions.
     * If the main watchpoint size exceeds 8 bytes, the function attempts 
     * to split the coverage into up to 4 smaller hardware-compatible 
     * blocks.
     *
     * The splitting strategy uses a hierarchical bitmap and recursive
     * refinement to minimize over-approximation. A strict recent-access
     * bias is applied: segments or qwords near a recent address are
     * prioritized during budget allocation and splitting.
     *
     * The overall procedure:
     * - Compute a coarse main watchpoint with computeWatchpoint().
     * - If the size is > 8 bytes, initialize recent bias fields.
     * - Invoke findRootLevelSplits() to produce up to 4 refined blocks.
     *
     * This allows large pages with scattered or bursty accesses to be
     * covered using multiple tight regions instead of one oversized block.
     *
     * @param[out] watchpoint         Coarse watchpoint covering all bytes.
     * @param[out] watchpointSplits   Output array of up to 4 watchpoints.
     * @param recentlyAccessedAddr    Optional recent address for biasing.
     * @return                        Number of refined watchpoints
     */
    size_t computeWatchpointSplits(Watchpoint& watchpoint, 
                                Watchpoint (&watchpointSplits)[4],
                                uint64_t recentlyAccessedAddr = UINT64_MAX) const;    

    /**
     * Print all tracked address groups in this page map.
     *
     * This function uses findGroups() to identify contiguous
     * regions of tracked bytes, then prints each group along
     * with all addresses it contains.
     *
     * If no addresses are being tracked, a message is printed
     * indicating that the page map is empty.
     */
    void printAddresses() const;

    /**
     * Print usage statistics for the current page map.
     *
     * This function reports the total number of tracked addresses,
     * the number of active qwords (8-byte blocks), and the number
     * of active byte positions. It also prints the percentage of
     * qwords and bytes in use relative to the page capacity.
     */
    void printStats() const;
};

#endif // PAGEMAP_H