/*
Copyright 2025 Jex Amro (Square Labs LLC)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#include "pagemap.h"
#include "common.h"

inline uint32_t PageMap::getQwordIndex(uint64_t addr) {
    return (addr & 0x3FFF) >> 3;  // Mask to 16K page size and divide by 8
}

inline uint8_t PageMap::getByteOffsetInQword(uint64_t addr) {
    return addr & 0x7;  // Get last 3 bits
}

inline void PageMap::markQwordSet(uint32_t qwordIndex) {
    uint32_t seg = qwordIndex >> 6;
    pageSegments[seg] |= 1ULL << (qwordIndex & 63);
    rootBitmap |= 1U << seg;
}

inline uint8_t PageMap::byteMask(uint8_t startOffset, uint8_t endOffset) const {
    return static_cast<uint8_t>(
        ((1U << (static_cast<uint32_t>(endOffset) + 1)) - 1) &
        (0xFFU << static_cast<uint32_t>(startOffset))
    );
}

uint64_t PageMap::wcr(uint64_t size, uint8_t qword_content) {
    uint32_t byte_address_select;
    uint32_t MASK = 0;

    if (size <= 8) {
        // For sizes <= 8, use the provided qword content
        // which already has the correct bits set
        byte_address_select = qword_content;
    } else {
        byte_address_select = 0xff;
        // For larger sizes, calculate the number of bits directly
        MASK = (63 - __builtin_clzll(size)) << 24;
    }

    byte_address_select <<= 5;
    return byte_address_select |    // Which bytes to watch
           MASK |                   // MASK
           S_USER |                 // Stop only in user mode
           WCR_LOAD |               // Stop on read access
           WCR_STORE |              // Stop on write access
           WCR_ENABLE;              // Enable this watchpoint
}

PageMap::PageMap() : addressCount(0), rootBitmap(0) {
    // Initialize all arrays to 0
    for (uint32_t i = 0; i < NUM_SEGMENTS; i++) {
        pageSegments[i] = 0;
    }
    for (uint32_t i = 0; i < NUM_QWORDS; i++) {
        pageQwords[i] = 0;
    }
}

uint32_t PageMap::size() const {
    return addressCount;
}

bool PageMap::empty() const {
    return addressCount == 0;
}

bool PageMap::hasAddress(uint64_t addr, uint32_t size) const {

    LOG("[PageMap::hasAddress] %llx[%u]\n", addr,size);
    if (size == 1) {
        uint32_t qwordIndex = getQwordIndex(addr);
        uint8_t byteOffset = getByteOffsetInQword(addr);
        return (pageQwords[qwordIndex] & (1 << byteOffset)) != 0;
    }

    uint64_t lastAddr = addr + size - 1;
    uint32_t firstQwordIndex = getQwordIndex(addr);
    uint32_t lastQwordIndex = getQwordIndex(lastAddr);
    uint8_t firstByteOffset = getByteOffsetInQword(addr);
    uint8_t lastByteOffset = getByteOffsetInQword(lastAddr);

    // If range is within single qword
    if (firstQwordIndex == lastQwordIndex) {
        uint8_t mask = byteMask(firstByteOffset, lastByteOffset);
        return (pageQwords[firstQwordIndex] & mask) != 0;
    }

    // Check first partial qword
    uint8_t firstMask = byteMask(firstByteOffset, 7);
    if ((pageQwords[firstQwordIndex] & firstMask) != 0)
        return true;

    // Check all middle qwords
    for (uint32_t qwordIndex = firstQwordIndex + 1; qwordIndex < lastQwordIndex; qwordIndex++) {
        if (pageQwords[qwordIndex] != 0)
            return true;
    }

    // Check last partial qword
    uint8_t lastMask = byteMask(0, lastByteOffset);
    if ((pageQwords[lastQwordIndex] & lastMask) != 0)
        return true;

    return false;
}

uint32_t PageMap::add(uint64_t addr, uint32_t size) {
    if (size == 1) {
        // Fast path for single address
        uint32_t qwordIndex = getQwordIndex(addr);
        uint8_t byteOffset = getByteOffsetInQword(addr);

        // Check if the bit was not previously set
        if ((pageQwords[qwordIndex] & (1 << byteOffset)) == 0) {

            markQwordSet(qwordIndex);

            pageQwords[qwordIndex] |= 1 << byteOffset;
            addressCount++;
            return 1;
        }
        return 0;
    }

    // Handle range of addresses
    uint64_t endAddr = addr + size - 1;
    uint32_t startQwordIndex = getQwordIndex(addr);
    uint32_t endQwordIndex = getQwordIndex(endAddr);
    uint8_t startByteOffset = getByteOffsetInQword(addr);
    uint8_t endByteOffset = getByteOffsetInQword(endAddr);
    uint32_t segmentIndex = startQwordIndex >> 6;


    // If range is within single qword
    if (startQwordIndex == endQwordIndex) {
        // Create bitmask covering only the byte range [startByteOffset..endByteOffset] inside one qword
        uint8_t mask = byteMask(startByteOffset, endByteOffset);
        uint8_t newBits = mask & ~pageQwords[startQwordIndex];
        uint32_t added = __builtin_popcount(newBits);
        pageQwords[startQwordIndex] |= mask;
        markQwordSet(startQwordIndex);

        addressCount += added;
        return added;
    }

    uint32_t addedCount = 0;

    // Handle first partial qword
    uint8_t firstMask = static_cast<uint8_t>(0xFF << startByteOffset);
    uint8_t firstNewBits = firstMask & ~pageQwords[startQwordIndex];
    addedCount += __builtin_popcount(firstNewBits);
    pageQwords[startQwordIndex] |= firstMask;
    markQwordSet(startQwordIndex);

    // Handle middle complete qwords
    for (uint32_t qwordIndex = startQwordIndex + 1; qwordIndex < endQwordIndex; qwordIndex++) {
        addedCount += 8 - __builtin_popcount(pageQwords[qwordIndex]);
        pageQwords[qwordIndex] = 0xFF;

        // todo: make markQwordSet return the marked segment index
        //       to keep track and skip re-setting the same bits
        markQwordSet(qwordIndex);
    }

    // Handle last partial qword
    uint8_t lastMask = byteMask(0, endByteOffset);
    uint8_t lastNewBits = lastMask & ~pageQwords[endQwordIndex];
    addedCount += __builtin_popcount(lastNewBits);
    pageQwords[endQwordIndex] |= lastMask;
    markQwordSet(endQwordIndex);

    addressCount += addedCount;
    return addedCount;
}

inline void PageMap::unmarkQwordIfEmpty(uint32_t qwordIndex) {
    if (pageQwords[qwordIndex] == 0) {
        uint32_t seg = qwordIndex >> 6;
        pageSegments[seg] &= ~(1ULL << (qwordIndex & 63));
        if (pageSegments[seg] == 0) {
            rootBitmap &= ~(1U << seg);
        }
    }
}

uint32_t PageMap::remove(uint64_t addr, uint32_t size) {
    if (size == 1) {
        // Fast path for single address
        uint32_t qwordIndex = getQwordIndex(addr);
        uint32_t segmentIndex = qwordIndex >> 6;

        // Early exit if segment not marked
        if (!(rootBitmap & (1U << segmentIndex))) {
            return 0;
        }
        
        // Second check if segment bit is set
        if ((pageSegments[segmentIndex] & (1ULL << (qwordIndex & 63))) == 0) {
            return 0;  // Early return if segment bit not set
        }
        
        uint8_t byteOffset = getByteOffsetInQword(addr);
        if (pageQwords[qwordIndex] & (1 << byteOffset)) {
            pageQwords[qwordIndex] &= ~(1 << byteOffset);
            addressCount--;

            unmarkQwordIfEmpty(qwordIndex);

            return 1;
        }
        return 0;
    }

    uint64_t endAddr = addr + size - 1;
    uint32_t startQwordIndex = getQwordIndex(addr);
    uint32_t endQwordIndex = getQwordIndex(endAddr);
    uint8_t startByteOffset = getByteOffsetInQword(addr);
    uint8_t endByteOffset = getByteOffsetInQword(endAddr);
    uint32_t segmentIndex = startQwordIndex >> 6;

    // If range is within single qword
    if (startQwordIndex == endQwordIndex) {
        // Check segment bit first
        if ((pageSegments[startQwordIndex >> 6] & (1ULL << (startQwordIndex & 63))) == 0) {
            return 0;
        }
        
        uint8_t mask = byteMask(startByteOffset, endByteOffset);
        uint8_t removedBits = pageQwords[startQwordIndex] & mask;
        uint32_t removed = __builtin_popcount(removedBits);
        pageQwords[startQwordIndex] &= ~mask;

        unmarkQwordIfEmpty(startQwordIndex);

        addressCount -= removed;
        return removed;
    }

    uint32_t removedCount = 0;

    // Handle first partial qword if its segment bit is set
    if (pageSegments[segmentIndex] & (1ULL << (startQwordIndex & 63))) {
        uint8_t firstMask = static_cast<uint8_t>(0xFF << startByteOffset);
        uint8_t firstRemovedBits = pageQwords[startQwordIndex] & firstMask;
        pageQwords[startQwordIndex] &= ~firstMask;
        removedCount += __builtin_popcount(firstRemovedBits);
        
        unmarkQwordIfEmpty(startQwordIndex);
    }

    uint32_t markedSegmentIndex = 0;

    // Handle middle complete qwords
    for (uint32_t qwordIndex = startQwordIndex + 1; qwordIndex < endQwordIndex; qwordIndex++) {
        segmentIndex = qwordIndex >> 6;
        // Only process if segment bit is set
        if (pageSegments[segmentIndex] & (1ULL << (qwordIndex & 63))) {
            removedCount += __builtin_popcount(pageQwords[qwordIndex]);
            pageQwords[qwordIndex] = 0;
            if (segmentIndex != markedSegmentIndex) {
                pageSegments[segmentIndex] &= ~(1ULL << (qwordIndex & 63));
                rootBitmap &= ~(1U << segmentIndex);
                markedSegmentIndex = segmentIndex;
            }
        }
    }

    segmentIndex = endQwordIndex >> 6;

    // Handle the final qword in the range (partial), if segment bit is set
    if (endQwordIndex != startQwordIndex && 
        (pageSegments[segmentIndex] & (1ULL << (endQwordIndex & 63)))) {

        uint8_t lastMask = byteMask(0, endByteOffset);
        uint8_t lastRemovedBits = pageQwords[endQwordIndex] & lastMask;
        pageQwords[endQwordIndex] &= ~lastMask;
        removedCount += __builtin_popcount(lastRemovedBits);

        // ToDo: pass markedSegmentIndex parameter to skip re-setting!
        unmarkQwordIfEmpty(endQwordIndex);

    }

    addressCount -= removedCount;
    return removedCount;
}

uint32_t PageMap::removeAddressesLowerThan(uint64_t addr) {
    uint32_t removedCount = 0;
    uint32_t targetQwordIndex = getQwordIndex(addr);
    uint8_t targetByteOffset = getByteOffsetInQword(addr);
    
    uint32_t lastSegmentIndex = targetQwordIndex >> 6;

    // Process complete segments before the target qword
    for (uint32_t segmentIndex = 0; segmentIndex < lastSegmentIndex; segmentIndex++) {
        // Skip segment if not set in rootBitmap
        if (!(rootBitmap & (1U << segmentIndex))) continue;

        uint64_t segmentBits = pageSegments[segmentIndex];
        // Process only qwords that have their segment bit set
        for (uint32_t i = 0; i < 64; i++) {
            if (segmentBits & (1ULL << i)) {
                uint32_t qwordIndex = segmentIndex * 64 + i;
                removedCount += __builtin_popcount(pageQwords[qwordIndex]);
                pageQwords[qwordIndex] = 0;
            }
        }
        pageSegments[segmentIndex] = 0;
        rootBitmap &= ~(1U << segmentIndex);
    }
    
    // Handle all qwords before the target qword in the last segment
    uint64_t lastSegmentBits = pageSegments[lastSegmentIndex];

    for (uint32_t qwordIndex = lastSegmentIndex * 64; qwordIndex < targetQwordIndex; qwordIndex++) {
        uint32_t bitOffset = qwordIndex & 63;
        if (lastSegmentBits & (1ULL << bitOffset)) {
            removedCount += __builtin_popcount(pageQwords[qwordIndex]);
            pageQwords[qwordIndex] = 0;
            lastSegmentBits &= ~(1ULL << bitOffset);
        }
    }

    // Stack Address is already aligned no need to handle last Qword bytes

    // Commit updated segment bits
    pageSegments[lastSegmentIndex] = lastSegmentBits;
    if (lastSegmentBits == 0) {
        rootBitmap &= ~(1U << lastSegmentIndex);
    }

    addressCount -= removedCount;
    return removedCount;
}

std::vector<std::pair<uint64_t, uint32_t>> PageMap::findGroups() const {
    std::vector<std::pair<uint64_t, uint32_t>> groups;
    uint64_t groupStartAddr = 0;
    bool inGroup = false;
    uint64_t lastAddr = 0;

    // Skip segments not set in rootBitmap
    uint32_t remainingSegments = rootBitmap;
    while (remainingSegments) {
        // Find next used segment
        uint32_t segmentIndex = __builtin_ctz(remainingSegments);
        uint64_t segmentBits = pageSegments[segmentIndex];
        
        // Skip if segment is empty (shouldn't happen if rootBitmap is maintained correctly)
        if (segmentBits == 0) {
            remainingSegments &= ~(1U << segmentIndex);
            continue;
        }

        // Process each set qword in this segment
        uint64_t remainingQwords = segmentBits;
        while (remainingQwords) {
            // Find next used qword
            uint32_t qwordOffset = __builtin_ctzll(remainingQwords);
            uint32_t qwordIndex = segmentIndex * 64 + qwordOffset;
            
            if (qwordIndex >= NUM_QWORDS) break;

            uint8_t qwordBits = pageQwords[qwordIndex];
            if (qwordBits) {
                uint64_t baseAddr = qwordIndex * QWORD_SIZE;
                
                // Process each set bit in the qword
                while (qwordBits) {
                    uint8_t bitPos = __builtin_ffs(qwordBits) - 1;
                    uint64_t currentAddr = baseAddr + bitPos;
                    
                    if (!inGroup) {
                        groupStartAddr = currentAddr;
                        inGroup = true;
                    } else if (currentAddr != lastAddr + 1) {
                        // End current group and start new one
                        groups.emplace_back(groupStartAddr, lastAddr - groupStartAddr + 1);
                        groupStartAddr = currentAddr;
                    }
                    lastAddr = currentAddr;
                    
                    // Clear processed bit
                    qwordBits &= ~(1 << bitPos);
                }
            }
            
            // Clear processed qword
            remainingQwords &= ~(1ULL << qwordOffset);
        }
        
        // Clear processed segment
        remainingSegments &= ~(1U << segmentIndex);
    }

    // Add final group if we ended while in a group
    if (inGroup) {
        groups.emplace_back(groupStartAddr, lastAddr - groupStartAddr + 1);
    }
    
    return groups;
}


std::vector<uint8_t> PageMap::getUsedByteOffsetsInQword(uint32_t qwordIndex) const {
    std::vector<uint8_t> usedOffsets;
    
    // First check if segment bit is set
    if ((pageSegments[qwordIndex >> 6] & (1ULL << (qwordIndex & 63))) == 0) {
        return usedOffsets;  // Return empty vector if qword is not in use
    }
    
    // Only examine qword bits if segment bit was set
    uint8_t byteBits = pageQwords[qwordIndex];
    while (byteBits) {
        uint8_t bitPos = __builtin_ffs(byteBits) - 1;
        usedOffsets.push_back(bitPos);
        byteBits &= ~(1 << bitPos);
    }
    
    return usedOffsets;
}

uint64_t PageMap::getLowestAddress() const {
    if (addressCount == 0) {
        return UINT64_MAX;
    }

    // Find first used segment
    for (uint32_t i = 0; i < NUM_SEGMENTS; i++) {
        if (pageSegments[i] != 0) {
            // Find first used qword in this segment
            uint32_t qwordOffset = __builtin_ffsll(pageSegments[i]) - 1;
            uint32_t qwordIndex = (i * 64) + qwordOffset;
            
            // Find first used bit in this qword
            uint8_t firstByte = pageQwords[qwordIndex];
            uint64_t bitOffset = __builtin_ffs(firstByte) - 1;
            
            return (qwordIndex * 8) + bitOffset + pageBaseAddr;
        }
    }
    return UINT64_MAX;  // Should never reach here if addressCount > 0
}

uint64_t PageMap::getHighestAddress() const {
    if (addressCount == 0) {
        return UINT64_MAX;
    }

    // Find last used segment
    for (uint32_t i = NUM_SEGMENTS; i-- > 0;) {
        if (pageSegments[i] != 0) {
            // Find last used qword in this segment
            uint32_t qwordOffset = 63 - __builtin_clzll(pageSegments[i]);
            uint32_t qwordIndex = (i * 64) + qwordOffset;
            
            // Find last used bit in this qword
            uint8_t lastByte = pageQwords[qwordIndex];
            //uint64_t bitOffset = 7 - __builtin_clz(lastByte);
            uint32_t bitOffset = 7 - __builtin_clz((unsigned int)(lastByte & 0xFF) << 24);
            
            return ((qwordIndex * 8) + bitOffset) + pageBaseAddr;
        }
    }
    return UINT64_MAX;  // Should never reach here if addressCount > 0
}

inline void PageMap::emitWatchpoint(Watchpoint& wp, uint64_t addr, uint64_t size) const {
    wp.address = addr;
    wp.size = size;

    if (size <= 8) {
        uint32_t qwordIndex = getQwordIndex(addr);
        wp.wcr = wcr(size, pageQwords[qwordIndex]);
    } else {
        wp.wcr = wcr(size);
    }
}

void PageMap::findOptimalWatchpoint(uint32_t bits, uint32_t startPos, uint32_t width, Watchpoint& wp) const {

    if (!bits)
        FATAL("[findOptimalWatchpoint] bits = 0");
    
    // Base case: single bit
    if (width == 1) {
        refineSegmentWatchpoint(startPos, wp);
        return;
    }

    uint32_t halfWidth = width >> 1;
    //LOG("halfWidth: %d\n",halfWidth);
    uint32_t lowMask = ((1U << halfWidth) - 1) << startPos;
    uint32_t highMask = ((1U << halfWidth) - 1) << (startPos + halfWidth);

    uint32_t lowBits = bits & lowMask;
    uint32_t highBits = bits & highMask;


    // If both halves have bits, use current level
    if (lowBits && highBits) {
        emitWatchpoint(wp, pageBaseAddr + (startPos * 512), width * 512);
        return;
    }

    // Otherwise, optimize to the non-empty half
    uint32_t usedBits = lowBits ? lowBits : highBits;
    uint32_t newStartPos = lowBits ? startPos : (startPos + halfWidth);
    findOptimalWatchpoint(usedBits, newStartPos, halfWidth, wp);
}

void PageMap::refineSegmentWatchpoint(uint32_t segmentIndex, Watchpoint& wp) const {
    uint64_t bits = pageSegments[segmentIndex];

    if (!bits)
        FATAL("[refineSegmentWatchpoint] segmentBits = 0");

    uint32_t startPos = 0;
    uint32_t width = 64;

    while (width > 1) {
        uint32_t halfWidth = width >> 1;
        uint64_t lowMask = ((1ULL << halfWidth) - 1) << startPos;
        uint64_t highMask = ((1ULL << halfWidth) - 1) << (startPos + halfWidth);

        uint64_t lowBits = bits & lowMask;
        uint64_t highBits = bits & highMask;

        if (!lowBits || !highBits) {
            bits = lowBits ? lowBits : highBits;
            startPos = lowBits ? startPos : (startPos + halfWidth);
            width = halfWidth;
            continue;
        }

        break;
    }

    // Final refined region
    uint64_t addr = pageBaseAddr + (segmentIndex * 512) + (startPos * 8);
    emitWatchpoint(wp, addr, width * 8);
}

void PageMap::refineRootSplit(RootWork& work) const {
    work.reductionRate = 0;
    while (work.width > 1) {
        uint32_t halfWidth = work.width >> 1;
        uint32_t lowMask = ((1U << halfWidth) - 1) << work.startPos;
        uint32_t highMask = ((1U << halfWidth) - 1) << (work.startPos + halfWidth);

        uint32_t lowBits = work.bits & lowMask;
        uint32_t highBits = work.bits & highMask;
        
        if (!lowBits || !highBits) {
            work.bits = lowBits ? lowBits : highBits;
            work.startPos = lowBits ? work.startPos : (work.startPos + halfWidth);
            work.width = halfWidth;
            work.reductionRate++;
            continue;
        }

        work.size = work.width * 512;

        return;  // Found valid split point
    }
    work.size = work.width * 512;
    return;
}


// Refining segment splits
void PageMap::refineSegmentSplit(SegmentWork& work) const {

    while (work.width > 1) {
        uint32_t halfWidth = work.width >> 1;
        uint64_t lowMask = ((1ULL << halfWidth) - 1) << work.startPos;
        uint64_t highMask = ((1ULL << halfWidth) - 1) << (work.startPos + halfWidth);

        uint64_t lowBits = work.bits & lowMask;
        uint64_t highBits = work.bits & highMask;
        
        if (!lowBits || !highBits) {
            work.bits = lowBits ? lowBits : highBits;
            work.startPos = lowBits ? work.startPos : (work.startPos + halfWidth);
            work.width = halfWidth;
            continue;
        }
        break;
    }

    work.size = work.width * 8; // Each bit represents 8 bytes
}

size_t PageMap::findSegmentLevelSplits(
    uint32_t segmentIndex,
    SegmentWork& work, 
    Watchpoint (&splits)[4], 
    size_t currentSplit, 
    size_t maxWatchpoints) const {

    LOG("[findSegmentLevelSplits]\n");
    std::cout << "   segmentIndex: " << segmentIndex << std::endl;
    std::cout << "    segmentBits: " << std::bitset<64>(work.bits) << std::endl;
    std::cout << "   currentSplit: " << currentSplit << std::endl;
    std::cout << " maxWatchpoints: " << maxWatchpoints << std::endl;

    if (!work.bits) return currentSplit;

    if (maxWatchpoints == 0)
        FATAL("Reached fallback with non-zero bits but no remaining watchpoints!");

    refineSegmentSplit(work);

    std::cout << " recentQwordBit: " << std::bitset<64>(recentQwordBit) << std::endl;

    uint64_t rangeMask = (work.width < 64) ? ((1ULL << work.width) - 1) << work.startPos : ~0ULL;

    if (work.width == 1 || 
        maxWatchpoints < 2 || 
        (segmentIndex != recentSegmentIndex) || 
        ((recentQwordBit & rangeMask) == 0)) {

        // Final fallback for segment-level span
        uint64_t baseAddr = pageBaseAddr + (segmentIndex * 512);
        emitWatchpoint(splits[currentSplit], baseAddr + (work.startPos * 8), work.size);

        return currentSplit + 1;
    }

    std::cout << "      rangeMask: " << std::bitset<64>(rangeMask) << std::endl;

    // Perform split
    uint32_t halfWidth = work.width >> 1;

    uint32_t lowStartPos = work.startPos;
    uint32_t highStartPos = work.startPos + halfWidth;

    uint64_t lowMask = ((1ULL << halfWidth) - 1) << lowStartPos;
    uint64_t highMask = ((1ULL << halfWidth) - 1) << highStartPos;

    uint64_t lowBits = work.bits & lowMask;
    uint64_t highBits = work.bits & highMask;

    // Handle both sides
    if (lowBits && highBits && maxWatchpoints >= 2) {
        // Apply strict bias: favor one side using recentQwordBit and limit the other to 1 watchpoint.
        std::cout << "       lowMask: " << std::bitset<64>(lowMask) << std::endl;

        bool favorLow = recentQwordBit & lowMask;
        size_t lowBudget = favorLow ? (maxWatchpoints - 1) : 1;

        size_t beforeLow = currentSplit;

        SegmentWork lowWork = {
            .bits = lowBits,
            .startPos = lowStartPos,
            .width = halfWidth,
            .size = 0
        };

        currentSplit = findSegmentLevelSplits(
            segmentIndex,
            lowWork, 
            splits, 
            currentSplit, 
            lowBudget // maxWatchpoints - 1 // reserve 1 for high side
        );

        size_t usedLow = currentSplit - beforeLow;
        size_t remainingForHigh = maxWatchpoints - usedLow;

        SegmentWork highWork = {
            .bits = highBits,
            .startPos = highStartPos,
            .width = halfWidth,
            .size = 0
        };

        return findSegmentLevelSplits(
            segmentIndex,
            highWork, 
            splits, 
            currentSplit, 
            remainingForHigh
        );
    }

    // Only low side has bits
    if (lowBits && maxWatchpoints > 0) {

        SegmentWork lowWork = {
            .bits = lowBits,
            .startPos = lowStartPos,
            .width = halfWidth,
            .size = 0
        };

        return findSegmentLevelSplits(
            segmentIndex,
            lowWork, 
            splits, 
            currentSplit, 
            maxWatchpoints
        );
    }

    // Only high side has bits
    if (highBits && maxWatchpoints > 0) {

        SegmentWork highWork = {
            .bits = highBits,
            .startPos = highStartPos,
            .width = halfWidth,
            .size = 0
        };

        return findSegmentLevelSplits(
            segmentIndex,
            highWork, 
            splits, 
            currentSplit, 
            maxWatchpoints
        );
    }

    // Final fallback if splitting is no longer possible or budget is exhausted
    if (work.bits != 0) {
        if (maxWatchpoints == 0)
            FATAL("Reached fallback in segment with non-zero bits but no remaining watchpoints!");

        uint64_t baseAddr = pageBaseAddr + (segmentIndex * 512);
        emitWatchpoint(splits[currentSplit], baseAddr + (work.startPos * 8), work.size);

        return currentSplit + 1;
    }
    return currentSplit;
}


// Main function for finding watchpoint splits
size_t PageMap::findRootLevelSplits(
    uint32_t bits, 
    uint32_t startPos, 
    uint32_t width, 
    Watchpoint (&splits)[4], 
    size_t currentSplit,
    size_t maxWatchpoints) const {

    LOG("[findRootLevelSplits]\n");
    std::cout << "             bits: " << std::bitset<32>(bits) << std::endl;
    std::cout << "         startPos: " << startPos << std::endl;
    std::cout << "            width: " << width << std::endl;
    std::cout << "     currentSplit: " << currentSplit << std::endl;
    std::cout << "   maxWatchpoints: " << maxWatchpoints << std::endl;

    if (!bits) return currentSplit;

    if (maxWatchpoints == 0)
        FATAL("running out of watchpoints before covering all addresses");

    // Start with initial work at rootBitmap layer
    RootWork work = {bits, startPos, width, 0, 0};
    refineRootSplit(work);

    // If we reached width=1 at rootBitmap layer, switch to segment layer
    if (work.width == 1) {
        uint32_t segmentIndex = work.startPos;
        if (segmentIndex >= NUM_SEGMENTS)
            FATAL("Invalid segment index in findRootLevelSplits: %u", segmentIndex);
        SegmentWork initialSegWork = {
            .bits = pageSegments[segmentIndex],
            .startPos = 0,
            .width = 64,
            .size = 512
        };
        return findSegmentLevelSplits(
            segmentIndex, 
            initialSegWork, 
            splits, 
            currentSplit, 
            maxWatchpoints);
    }

    if (maxWatchpoints < 2) {
        emitWatchpoint(splits[currentSplit], pageBaseAddr + work.startPos * 512, work.size);
        return currentSplit + 1;
    }

    uint32_t halfWidth = work.width >> 1;
    
    // If halfWidth is 1, we need to process each half at segment layer
    if (halfWidth == 1) {
        uint32_t lowSegIndex = work.startPos;
        uint32_t highSegIndex = work.startPos + 1;

        uint32_t lowSegBit = 1U << lowSegIndex;
        uint32_t highSegBit = 1U << highSegIndex;

        bool hasLow = bits & lowSegBit;
        bool hasHigh = bits & highSegBit;

        if (hasLow && hasHigh && maxWatchpoints >= 2) {

            // Apply strict bias: favor one side using recentSegmentBit and limit the other to 1 watchpoint.

            std::cout << " recentSegmentBit: " << std::bitset<32>(recentSegmentBit) << std::endl;
            std::cout << "       lowSegBit: " << std::bitset<32>(lowSegBit) << std::endl;

            // Determine whether to favor low side using recentSegmentBit
            bool favorLow = recentSegmentBit & lowSegBit;
            // Calculate budget for low side based on favoring
            size_t lowBudget = favorLow ? (maxWatchpoints - 1) : 1;

            size_t beforeLow = currentSplit;

            SegmentWork lowWork = {
                .bits = pageSegments[lowSegIndex],
                .startPos = 0,
                .width = 64,
                .size = 512
            };

            currentSplit = findSegmentLevelSplits(
                lowSegIndex,
                lowWork, 
                splits, 
                currentSplit, 
                lowBudget // maxWatchpoints - 1 // reserve 1 for high side
            );

            size_t usedLow = currentSplit - beforeLow;
            size_t remainingForHigh = maxWatchpoints - usedLow;

            SegmentWork highWork = {
                .bits = pageSegments[highSegIndex],
                .startPos = 0,
                .width = 64,
                .size = 512
            };

            return findSegmentLevelSplits(
                highSegIndex,
                highWork, 
                splits, 
                currentSplit, 
                remainingForHigh
            );
        }

        // If only one side has bits (or only one slot left), handle whichever exists
        if (hasLow && maxWatchpoints > 0) {
            
            SegmentWork lowWork = {
                .bits = pageSegments[lowSegIndex],
                .startPos = 0,
                .width = 64,
                .size = 512
            };

            return findSegmentLevelSplits(
                lowSegIndex,
                lowWork, 
                splits, 
                currentSplit, 
                maxWatchpoints
            );
        }

        if (hasHigh && maxWatchpoints > 0) {
            
            SegmentWork highWork = {
                .bits = pageSegments[highSegIndex],
                .startPos = 0,
                .width = 64,
                .size = 512
            };

            return findSegmentLevelSplits(
                highSegIndex,
                highWork, 
                splits, 
                currentSplit, 
                maxWatchpoints
            );
        }

        // We also get here if Neither side has bits
        return currentSplit;
    }

    // For larger halfWidths, continue with normal splitting
    uint32_t lowMask = ((1U << halfWidth) - 1) << work.startPos;
    uint32_t highMask = ((1U << halfWidth) - 1) << (work.startPos + halfWidth);
    
    uint32_t lowBits = work.bits & lowMask;
    uint32_t highBits = work.bits & highMask;
    
    // Handle both sides if they have bits and we have enough budget
    if (lowBits && highBits && maxWatchpoints >= 2) {
        RootWork lowWork = {lowBits, work.startPos, halfWidth, 0, 0};
        RootWork highWork = {highBits, work.startPos + halfWidth, halfWidth, 0, 0};

        refineRootSplit(lowWork);
        refineRootSplit(highWork);

        // Apply strict bias: favor one side using recentSegmentBit and limit the other to 1 watchpoint.

        // Determine whether to favor low side using recentSegmentBit
        bool favorLow = recentSegmentBit & lowMask;
        // Calculate budget for low side based on favoring
        size_t lowBudget = favorLow ? (maxWatchpoints - 1) : 1;

        size_t beforeLow = currentSplit;

        currentSplit = findRootLevelSplits(
            lowBits,
            lowWork.startPos,
            lowWork.width,
            splits,
            currentSplit,
            lowBudget // maxWatchpoints - 1  // reserve 1 for high side
        );

        size_t usedLow = currentSplit - beforeLow;
        size_t remainingForHigh = maxWatchpoints - usedLow;

        return findRootLevelSplits(
            highBits,
            highWork.startPos,
            highWork.width,
            splits,
            currentSplit,
            remainingForHigh
        );
    }

    // Handle only one non-empty side if we have budget
    if (lowBits && maxWatchpoints > 0) {
        RootWork lowWork = {lowBits, work.startPos, halfWidth, 0, 0};
        refineRootSplit(lowWork);

        return findRootLevelSplits(
            lowBits,
            lowWork.startPos,
            lowWork.width,
            splits,
            currentSplit,
            maxWatchpoints
        );
    }

    if (highBits && maxWatchpoints > 0) {
        RootWork highWork = {highBits, work.startPos + halfWidth, halfWidth, 0, 0};
        refineRootSplit(highWork);

        return findRootLevelSplits(
            highBits,
            highWork.startPos,
            highWork.width,
            splits,
            currentSplit,
            maxWatchpoints
        );
    }

    // Final fallback if splitting is no longer possible or budget is exhausted
    if (work.bits != 0) {
        if (maxWatchpoints == 0)
            FATAL("Reached fallback with non-zero bits but no remaining watchpoints!");
        emitWatchpoint(splits[currentSplit], pageBaseAddr + work.startPos * 512, work.size);
        return currentSplit + 1;
    }

    // No bits — don't emit anything
    return currentSplit;
}

void PageMap::computeWatchpoint(Watchpoint& watchpoint) const {
    if (addressCount == 0) {
        FATAL("[computeWatchpoint] addressCount == 0");
        return;
    }
    findOptimalWatchpoint(rootBitmap, 0, 32, watchpoint);
}

size_t PageMap::computeWatchpointSplits(Watchpoint& mainWatchpoint, 
                              Watchpoint (&splits)[4],
                              uint64_t recentlyAccessedAddr) const {
    if (addressCount == 0) return 0;

    computeWatchpoint(mainWatchpoint);
    // todo: return 0 = no splits?
    if (mainWatchpoint.size <= 8) return 0; // no splits

    // Compute bitmasks for biasing split budget toward recently accessed address.
    // These will be used in root and segment-level splitting decisions.
    uint32_t recentQwordIndex = getQwordIndex(recentlyAccessedAddr);
    recentSegmentIndex = recentQwordIndex >> 6;
    recentSegmentBit = (recentSegmentIndex < 32) ? (1U << recentSegmentIndex) : 0;
    recentQwordBit = (1ULL << (recentQwordIndex & 63));

    return findRootLevelSplits(rootBitmap, 0, 32, splits, 0, 4);
}

void PageMap::printAddresses() const {
    auto groups = findGroups();
    
    if (groups.empty()) {
        LOG("No addresses tracked in this page map\n");
        return;
    }
    
    for (uint32_t groupNum = 0; groupNum < groups.size(); groupNum++) {
        const auto& group = groups[groupNum];
        uint64_t startAddr = group.first;
        uint32_t size = group.second;
        
        LOG("Group %u: %016llx - %016llx (size: %u)\n", 
            groupNum + 1, startAddr, startAddr + size - 1, size);
        
        // Print individual addresses in this group
        LOG("  Addresses in group %u:\n", groupNum + 1);
        for (uint64_t addr = startAddr; addr < startAddr + size; addr++) {
            LOG("    %016llx\n", addr);
        }
        LOG("\n");
    }
}

void PageMap::printStats() const {
    uint32_t usedQwords = 0;
    uint32_t usedBytes = 0;
    
    for (uint32_t i = 0; i < NUM_SEGMENTS; i++) {
        usedQwords += __builtin_popcountll(pageSegments[i]);
    }
    
    for (uint32_t i = 0; i < NUM_QWORDS; i++) {
        usedBytes += __builtin_popcount(pageQwords[i]);
    }
    
    LOG("Total tracked addresses: %u\n", addressCount);
    LOG("Used qwords: %u/%zu (%.2f%%)\n", 
           usedQwords, NUM_QWORDS, 
           (100.0 * usedQwords) / NUM_QWORDS);
    LOG("Used byte positions: %u/%zu (%.2f%%)\n", 
           usedBytes, NUM_QWORDS * 8,
           (100.0 * usedBytes) / (NUM_QWORDS * 8));
}