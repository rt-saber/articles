/*
Copyright 2025 Jex Amro (Square Labs LLC)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

/**
 * MemoryGuard
 *
 * A runtime protection module that configures page permissions and
 * manages AArch64 hardware watchpoints to monitor access to untrusted
 * input with efficient, fine-grained precision.
 *
 * Designed for use in dynamic analysis, and Selective Symbolic 
 * Instrumentation on macOS.
 * 
 * Key Features:
 *   - Bitmap-based address tracking (PageMap)
 *   - Dynamic watchpoint assignment
 *   - Recent-access bias for improved coverage
 *   - Stack-aware trimming of local variables
 *   - Support for stepping via temporary unguarding
 */

#ifndef MEMORYGUARD_H
#define MEMORYGUARD_H

#include <map>
#include <deque>
#include <unordered_set>
#include <set>
#include <mach/mach.h>
#include <mach/mach_vm.h>

#include "pagemap.h"
#include "watchpoint.h"
#include "macOS/machtarget.h"
extern "C" {
  #include "macOS/mig_server.h"
}

// Watchpoint and breakpoint control constants
#define BREAKPOINT_ENABLE   5
#define BREAKPOINT_DISABLE  4
#define S_USER              ((uint32_t)(2u << 1))
#define BCR_ENABLE          ((uint32_t)(1u))
#define WCR_ENABLE          ((uint32_t)(1u))
#define WCR_LOAD            ((uint32_t)(1u << 3))
#define WCR_STORE           ((uint32_t)(1u << 4))
#define MDE_ENABLE          ((uint32_t)(1u << 15))
#define SS_ENABLE           ((uint32_t)(1u))

class MemoryGuard {
private:
    /**
     * Tracks state and access information for a single 16 KB page.
     */
    struct PageInfo {
        bool isInitialized = false;
        vm_prot_t protection = 0;
        bool isStack = false;
        uint64_t pageBaseAddr = 0;

        PageMap addressMap;
        bool recentlyAccessed = false;
        uint64_t recentlyAccessedAddress = 0;
        uint64_t range = 0;
        bool updateWatchpoint = true;

        Watchpoint watchpoint;
        Watchpoint watchpointSplits[4];
        size_t numSplitWatchpoints = 0;
    };

    MachTarget* mach_target;
    bool debug;
    uint64_t pageSize;

    static constexpr size_t maxAccessPages = 4;

    std::deque<uint64_t> recentPages;
    size_t oldestPageIndex = 0;
    uint64_t lastAccessedPage = 0;
    uint64_t lastAccessedPageCount = 0;

public:
    /** Current hardware debug state for the task. */
    arm_debug_state64_t taskState;

    /** Maps page base address to PageInfo structures. */
    std::map<uint64_t, PageInfo> guardedPages;

    /** Tracks pages that have temporarily disabled protections. */
    std::unordered_set<uint64_t> steppingPages;

    /** Whether stepping is currently active. */
    bool stepping = true;

    /** Flag indicating whether any watchpoint data has changed. */
    bool hasUpdatedPages = false;

    /** Number of bytes actively tracked across all pages. */
    uint32_t totalGuarded = 0;

    /**
     * Constructor: initializes the MemoryGuard system.
     *
     * @param mach_target  Target process being traced.
     * @param debug        Enables debug logging if true.
     */
    MemoryGuard(MachTarget* mach_target, bool debug);

    /**
     * Destructor.
     */
    ~MemoryGuard() = default;

    /**
     * Fetch ARM debug register state for the target task.
     */
    void taskGetState();

    /**
     * Clear all hardware debug watchpoints (WVR/WCR).
     */
    void clearTaskState();

    /**
     * Return the index of the first available WVR slot, or -1 if full.
     */
    int getFreeWVR();

    /**
     * Notify MemoryGuard of a memory access.
     *
     * @param address  The address that was accessed.
     */
    void memAccess(uint64_t address);

    /**
     * Mark an entire page as recently accessed.
     *
     * @param page  Base address of the page.
     */
    void pageAccess(uint64_t page);

    /**
     * Check if a page was recently accessed.
     *
     * @param page  Page base address.
     * @return      True if in the recent page deque.
     */
    bool isPageRecentlyAccessed(uint64_t page) const;

    /**
     * Print list of recently accessed pages (for debugging).
     */
    void debugPrintRecentlyAccessedPages();

    /**
     * Compute a WCR (Watchpoint Control Register) value.
     *
     * @param address  Aligned watchpoint base address.
     * @param size     Watchpoint size (power of two).
     * @return         WCR bitfield.
     */
    uint64_t wcr(uint64_t address, uint64_t size);

    /**
     * Compute WCR MASK field based on size.
     *
     * @param size  Size of watchpoint.
     * @return      Encoded MASK bits.
     */
    uint32_t wcrMask(uint64_t size);

    /**
     * Add memory region to tracking.
     *
     * @param address   Start address.
     * @param size      Number of bytes.
     * @param isStack   True if address is stack memory.
     * @param step      If true, enter stepping mode.
     */
    void add(uint64_t address, uint32_t size,
             bool isStack = false, bool step = false);

    /**
     * Remove a memory region from tracking.
     *
     * @param address  Start address.
     * @param size     Number of bytes.
     */
    void remove(uint64_t address, uint32_t size);

    /**
     * Remove and restore protections for a given page.
     *
     * @param page      Base address of page.
     * @param pageInfo  PageInfo to remove.
     */
    void removePage(uint64_t page, PageInfo& pageInfo);

    /**
     * Remove all tracked memory and reset protections.
     */
    void removeAll();

    /**
     * Trim stack-local variables below given SP.
     *
     * @param sp  Stack pointer.
     */
    void removeLocalVariables(uint64_t sp);

    /**
     * Check whether any address in a range is tracked.
     *
     * @param address  Start address.
     * @param size     Number of bytes.
     * @return         True if any tracked byte is found.
     */
    bool isGuarded(uint64_t address, uint32_t size);

    /**
     * Check whether a page is in the guard set.
     *
     * @param address  Any address in the page.
     * @return         True if page is guarded.
     */
    bool isGuardedPage(uint64_t address);

    /**
     * Returns true if any byte overlaps with a guarded page.
     *
     * @param address  Start address.
     * @param size     Number of bytes.
     * @return         True if overlap is found.
     */
    bool isGuardedAccess(uint64_t address, uint32_t size = 1);

    /**
     * Print number of tracked bytes per page.
     */
    void logPagesInfo();

    /**
     * Disable all protections across all pages.
     */
    void unguardAllPages();

    /**
     * Restore protections and reapply all watchpoints.
     */
    void guardAllPages();

    /**
     * Temporarily unprotect memory to step over instruction.
     *
     * @param address  Faulting address.
     * @param size     Instruction size.
     */
    void step(uint64_t address, uint32_t size);

    /**
     * Reapply protections to any pages being stepped.
     */
    void protectSteppingPages();

    /**
     * Apply all updated watchpoint configurations.
     */
    void updateWatchpoints();

    /**
     * Recompute the single full-page watchpoint for a page.
     *
     * @param page  Reference to PageInfo object.
     */
    void updatePageWatchpoint(PageInfo& page);

    /**
     * Recompute split watchpoints for a page using bitmap data.
     *
     * @param page  Reference to PageInfo object.
     */
    void updatePageSplitWatchpoints(PageInfo& page);
};

#endif /* MEMORYGUARD_H */
